'use client';

import { useMemo, useState } from 'react';
import { cars, carCategories, type Car, type CarCategory } from '@/lib/car-data';
import { CarCard } from '@/components/car-card';
import { CarDetailsModal } from '@/components/car-details-modal';
import {
  FilterSidebar,
  type Filters,
} from '@/components/filter-sidebar';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SlidersHorizontal } from 'lucide-react';

const defaultFilters: Filters = {
  carTypes: [],
  budget: [500, 5000],
  seating: [],
  fuelTypes: [],
  acOnly: false,
  minDriverRating: 0,
};

export default function CarsPage() {
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const [sortBy, setSortBy] = useState('recommended');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedCar, setSelectedCar] = useState<Car | null>(null);
  const [activeCategory, setActiveCategory] = useState<CarCategory | 'All'>('All');

  const filteredCars = useMemo(() => {
    let result = cars.filter((car) => {
      if (activeCategory !== 'All' && car.category !== activeCategory)
        return false;
      if (filters.carTypes.length > 0 && !filters.carTypes.includes(car.category))
        return false;
      if (car.price < filters.budget[0] || car.price > filters.budget[1])
        return false;
      if (filters.seating.length > 0 && !filters.seating.includes(car.seats))
        return false;
      if (filters.fuelTypes.length > 0 && !filters.fuelTypes.includes(car.fuel))
        return false;
      if (filters.acOnly && !car.ac) return false;
      if (car.rating < filters.minDriverRating) return false;
      return true;
    });

    switch (sortBy) {
      case 'price-low':
        result = [...result].sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result = [...result].sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result = [...result].sort((a, b) => b.rating - a.rating);
        break;
    }

    return result;
  }, [filters, sortBy, activeCategory]);

  const resetFilters = () => {
    setFilters(defaultFilters);
    setActiveCategory('All');
  };

  return (
    <main className="min-h-screen bg-white">
      <Navbar />

      {/* Page header */}
      <section className="bg-charcoal-gradient pt-32 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-2 text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-gold">
              TripWheels Fleet
            </span>
            <h1 className="font-playfair text-3xl font-bold text-white sm:text-4xl md:text-5xl">
              Find the Right Car for Your Journey
            </h1>
            <p className="mx-auto max-w-xl text-base text-white/70">
              Choose a vehicle that fits your trip, your group and your budget.
            </p>
          </div>
        </div>
      </section>

      {/* Category tabs */}
      <section className="border-b border-charcoal/8 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 overflow-x-auto py-4 sm:gap-3">
            <button
              onClick={() => setActiveCategory('All')}
              className={`shrink-0 rounded-lg px-4 py-2 text-sm font-semibold transition-all duration-300 ${
                activeCategory === 'All'
                  ? 'bg-charcoal-gradient text-gold shadow-sm'
                  : 'border border-charcoal/15 text-charcoal/70 hover:border-gold/50'
              }`}
            >
              All Cars
            </button>
            {carCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`shrink-0 rounded-lg px-4 py-2 text-sm font-semibold transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-charcoal-gradient text-gold shadow-sm'
                    : 'border border-charcoal/15 text-charcoal/70 hover:border-gold/50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main content */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex gap-8">
          {/* Filter sidebar (desktop) */}
          <FilterSidebar
            filters={filters}
            setFilters={setFilters}
            resultCount={filteredCars.length}
            onReset={resetFilters}
            mobileOpen={mobileOpen}
            setMobileOpen={setMobileOpen}
          />

          {/* Car grid */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="mb-6 flex items-center justify-between rounded-xl border border-charcoal/8 bg-white px-4 py-3">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4 text-gold-dark" />
                <span className="text-sm font-medium text-charcoal">
                  {filteredCars.length} {filteredCars.length === 1 ? 'car' : 'cars'} available
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="hidden text-sm text-charcoal/50 sm:inline">
                  Sort by:
                </span>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="h-9 w-40 border-charcoal/15 text-sm text-charcoal">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Grid */}
            {filteredCars.length > 0 ? (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {filteredCars.map((car) => (
                  <CarCard
                    key={car.id}
                    car={car}
                    onViewDetails={setSelectedCar}
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-charcoal/8 bg-white py-24 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-charcoal/5">
                  <SlidersHorizontal className="h-7 w-7 text-charcoal/40" />
                </div>
                <h3 className="font-playfair text-xl font-bold text-charcoal">
                  No cars match your filters
                </h3>
                <p className="mt-2 text-sm text-charcoal/50">
                  Try adjusting your filters or resetting them to see all
                  available cars.
                </p>
                <button
                  onClick={resetFilters}
                  className="mt-4 rounded-lg bg-gold-gradient px-6 py-2.5 text-sm font-semibold text-charcoal transition-opacity hover:opacity-90"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Car details modal */}
      <CarDetailsModal
        car={selectedCar}
        onClose={() => setSelectedCar(null)}
      />

      <Footer />
    </main>
  );
}
