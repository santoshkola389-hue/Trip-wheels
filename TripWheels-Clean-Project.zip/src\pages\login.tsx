'use client';

import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Mail, Lock, Eye, EyeOff, Car, ArrowLeft, CheckCircle2, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth-provider';

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { signIn } = useAuth();

  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loadingAction, setLoadingAction] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast({
        title: "Please enter your email",
        description: "You can type any email to test sign in.",
        variant: "destructive",
      });
      return;
    }

    setLoadingAction('form');
    
    // Simulate real authentication process
    setTimeout(async () => {
      await signIn(email, fullName);
      setLoadingAction(null);
      
      const displayName = fullName.trim() || email.split('@')[0];
      toast({
        title: isSignUp ? "Account Created!" : "Welcome back!",
        description: `Successfully signed in as ${displayName}. Redirecting to TripWheels...`,
      });
      
      // Move to homepage
      setLocation('/');
    }, 750);
  };

  const handleSocialLogin = async (provider: string, demoEmail: string, demoName: string, demoAvatar?: string) => {
    setLoadingAction(provider);
    setTimeout(async () => {
      await signIn(demoEmail, demoName, demoAvatar);
      setLoadingAction(null);
      toast({
        title: `Signed in with ${provider}!`,
        description: `Welcome to TripWheels, ${demoName}.`,
      });
      setLocation('/');
    }, 650);
  };

  return (
    <div className="min-h-screen w-full bg-[#eef2f5] flex items-center justify-center p-3 sm:p-6 lg:p-10 font-sans">
      <div className="w-full max-w-5xl min-h-[640px] bg-white rounded-2xl lg:rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-2">
        
        {/* LEFT COLUMN: Clean White Login Form */}
        <div className="p-8 sm:p-12 lg:p-14 flex flex-col justify-between">
          
          {/* Top Bar: Brand & Back */}
          <div className="flex items-center justify-between mb-8">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0c312d] text-white transition-transform group-hover:scale-105 shadow-sm">
                <Car className="h-5 w-5" />
              </div>
              <span className="text-lg font-bold tracking-tight text-gray-900">
                Trip<span className="text-[#0c312d]">Wheels</span>
              </span>
            </Link>

            <Link href="/" className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-[#0c312d] transition-colors">
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Home
            </Link>
          </div>

          {/* Form Header */}
          <div className="max-w-md w-full mx-auto">
            <div className="mb-6">
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 tracking-tight">
                {isSignUp ? "Create an Account" : "Welcome Back!"}
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-gray-500 leading-relaxed">
                {isSignUp
                  ? "Sign up to start booking luxury cars with trusted professional chauffeurs."
                  : "Sign in to access your dashboard, view bookings, and manage your journeys."}
              </p>
            </div>

            {/* Login / Sign Up Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {isSignUp && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Full Name
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Santhosh Kumar"
                      className="w-full rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#0c312d] focus:ring-1 focus:ring-[#0c312d] outline-none transition"
                    />
                  </div>
                </div>
              )}

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full rounded-lg border border-gray-300 pl-10 pr-3.5 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#0c312d] focus:ring-1 focus:ring-[#0c312d] outline-none transition"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full rounded-lg border border-gray-300 pl-10 pr-10 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#0c312d] focus:ring-1 focus:ring-[#0c312d] outline-none transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>

                {!isSignUp && (
                  <div className="mt-1.5 text-right">
                    <button
                      type="button"
                      onClick={() => toast({ title: "Reset Link Sent", description: "Password reset instructions have been emailed." })}
                      className="text-xs font-medium text-gray-600 hover:text-[#0c312d] transition"
                    >
                      Forgot Password?
                    </button>
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={Boolean(loadingAction)}
                className="w-full mt-2 rounded-lg bg-[#0c312d] hover:bg-[#13443e] text-white py-2.5 sm:py-3 text-sm font-semibold transition-all duration-200 shadow-md hover:shadow-lg disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
              >
                {loadingAction === 'form' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {isSignUp ? "Creating Account..." : "Signing in..."}
                  </>
                ) : (
                  isSignUp ? "Create Account" : "Sign In"
                )}
              </button>
            </form>

            {/* OR Divider */}
            <div className="relative my-5">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-gray-400 font-semibold tracking-wider">
                  OR
                </span>
              </div>
            </div>

            {/* Social Logins */}
            <div className="space-y-2.5">
              <button
                type="button"
                disabled={Boolean(loadingAction)}
                onClick={() => handleSocialLogin('Google', 'alex.rivera@gmail.com', 'Alex Rivera', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=160')}
                className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-xs sm:text-sm font-medium text-gray-700 transition cursor-pointer disabled:opacity-50"
              >
                {loadingAction === 'Google' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-[#0c312d]" />
                    Connecting Google...
                  </>
                ) : (
                  <>
                    <svg className="h-4 w-4" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    Continue with Google
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={Boolean(loadingAction)}
                onClick={() => handleSocialLogin('Apple', 'apple.traveler@icloud.com', 'Apple VIP User')}
                className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-xs sm:text-sm font-medium text-gray-700 transition cursor-pointer disabled:opacity-50"
              >
                {loadingAction === 'Apple' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-black" />
                    Connecting Apple ID...
                  </>
                ) : (
                  <>
                    <svg className="h-4 w-4 fill-current text-black" viewBox="0 0 24 24">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.38c.62-.75 1.04-1.8 1.01-2.85-.92.04-2.03.62-2.68 1.38-.57.66-.99 1.72-.94 2.76 1.03.08 2.07-.54 2.61-1.29z" />
                    </svg>
                    Continue with Apple
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Bottom Switch between Sign In and Sign Up */}
          <div className="mt-8 text-center text-xs sm:text-sm text-gray-500">
            {isSignUp ? (
              <>
                Already have an Account?{" "}
                <button
                  type="button"
                  onClick={() => setIsSignUp(false)}
                  className="font-semibold text-[#0c312d] hover:underline cursor-pointer"
                >
                  Sign In
                </button>
              </>
            ) : (
              <>
                Don't have an Account?{" "}
                <button
                  type="button"
                  onClick={() => setIsSignUp(true)}
                  className="font-semibold text-[#0c312d] hover:underline cursor-pointer"
                >
                  Sign Up
                </button>
              </>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Rich Dark Teal/Emerald Showcase (Matches Screenshot) */}
        <div className="relative bg-gradient-to-br from-[#0c312d] via-[#092522] to-[#041513] text-white p-8 sm:p-12 lg:p-14 flex flex-col justify-between overflow-hidden">
          
          {/* Subtle ambient lighting effects */}
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-teal-400/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Top Big Headline */}
          <div className="relative z-10 pt-2 lg:pt-6">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white leading-[1.25]">
              Revolutionize Travel with Smarter Journeys
            </h2>
          </div>

          {/* Middle: Testimonial Quote Block */}
          <div className="relative z-10 my-8">
            <div className="text-4xl font-serif text-teal-400/70 leading-none mb-2 font-bold">
              “
            </div>
            <p className="text-sm sm:text-base text-gray-200 leading-relaxed mb-6 font-normal">
              "TripWheels has completely transformed our travel experience. It’s reliable, punctual, and ensures our family and team journeys are always first-class."
            </p>

            <div className="flex items-center gap-3">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=160"
                alt="Michael Carter"
                className="h-11 w-11 rounded-full object-cover border-2 border-teal-400/30"
              />
              <div>
                <div className="font-semibold text-sm text-white flex items-center gap-1.5">
                  Michael Carter
                  <CheckCircle2 className="h-3.5 w-3.5 text-teal-400 inline" />
                </div>
                <div className="text-xs text-teal-200/70">
                  Software Engineer at DevCore
                </div>
              </div>
            </div>
          </div>

          {/* Bottom: Partner / Feature Badges */}
          <div className="relative z-10 border-t border-white/10 pt-6">
            <div className="text-[11px] font-semibold uppercase tracking-widest text-teal-200/60 mb-4">
              JOIN 10,000+ HAPPY TRAVELERS
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-gray-300/80 font-medium">
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
                Airport Rides
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
                Outstation Trips
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
                Verified Drivers
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400" />
                24/7 Support
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}