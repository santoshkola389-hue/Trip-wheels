'use client';

import { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  UserCheck,
  Car,
  Navigation,
  Flag,
  Loader2,
} from 'lucide-react';

const stages = [
  { icon: CheckCircle2, label: 'Booking Confirmed', description: 'Your trip is confirmed and ready' },
  { icon: UserCheck, label: 'Driver Assigned', description: 'A verified driver has been assigned' },
  { icon: Car, label: 'Driver Arriving', description: 'Your driver is on the way to pickup' },
  { icon: Navigation, label: 'Trip Started', description: 'Your journey has begun' },
  { icon: Flag, label: 'Trip Completed', description: 'You have reached your destination' },
];

export function TripStatusTracking() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  // Auto-advance the active step for demo purposes
  useEffect(() => {
    if (!visible) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev < stages.length - 1 ? prev + 1 : prev));
    }, 1500);
    return () => clearInterval(interval);
  }, [visible]);

  return (
    <section className="relative bg-white py-20 sm:py-28">
      <div ref={sectionRef} className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            Trip Status Tracking
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Track Your Journey in Real Time
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            From booking confirmation to arrival — follow every stage of your
            trip with live status updates.
          </p>
        </div>

        {/* Desktop: horizontal stepper */}
        <div className="hidden md:block">
          <div className="relative">
            {/* Background line */}
            <div className="absolute top-7 left-0 right-0 h-1 rounded-full bg-charcoal/10" />
            {/* Progress line */}
            <div
              className="absolute top-7 left-0 h-1 rounded-full bg-gold-gradient transition-all duration-700"
              style={{ width: `${(activeStep / (stages.length - 1)) * 100}%` }}
            />
            {/* Steps */}
            <div className="relative flex justify-between">
              {stages.map((stage, i) => {
                const Icon = stage.icon;
                const isComplete = i < activeStep;
                const isActive = i === activeStep;
                const isPending = i > activeStep;
                return (
                  <div
                    key={stage.label}
                    className="flex flex-col items-center"
                    style={{ width: '20%' }}
                  >
                    {/* Icon circle */}
                    <div
                      className={`flex h-14 w-14 items-center justify-center rounded-full border-2 transition-all duration-500 ${
                        isComplete
                          ? 'border-gold bg-gold-gradient text-charcoal'
                          : isActive
                          ? 'border-gold bg-white text-gold-dark scale-110 shadow-gold'
                          : 'border-charcoal/15 bg-white text-charcoal/30'
                      }`}
                    >
                      {isComplete ? (
                        <CheckCircle2 className="h-7 w-7" />
                      ) : isActive ? (
                        <Loader2 className="h-7 w-7 animate-spin" />
                      ) : (
                        <Icon className="h-7 w-7" />
                      )}
                    </div>
                    {/* Label */}
                    <div className="mt-4 text-center">
                      <p
                        className={`text-sm font-bold transition-colors duration-500 ${
                          isComplete || isActive ? 'text-charcoal' : 'text-charcoal/40'
                        }`}
                      >
                        {stage.label}
                      </p>
                      <p
                        className={`mt-1 max-w-[140px] text-xs transition-colors duration-500 ${
                          isComplete || isActive ? 'text-charcoal/60' : 'text-charcoal/30'
                        }`}
                      >
                        {stage.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Mobile: vertical stepper */}
        <div className="md:hidden">
          <div className="relative space-y-6">
            {stages.map((stage, i) => {
              const Icon = stage.icon;
              const isComplete = i < activeStep;
              const isActive = i === activeStep;
              return (
                <div key={stage.label} className="flex gap-4">
                  {/* Icon + line */}
                  <div className="flex flex-col items-center">
                    <div
                      className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-500 ${
                        isComplete
                          ? 'border-gold bg-gold-gradient text-charcoal'
                          : isActive
                          ? 'border-gold bg-white text-gold-dark scale-110 shadow-gold'
                          : 'border-charcoal/15 bg-white text-charcoal/30'
                      }`}
                    >
                      {isComplete ? (
                        <CheckCircle2 className="h-6 w-6" />
                      ) : isActive ? (
                        <Loader2 className="h-6 w-6 animate-spin" />
                      ) : (
                        <Icon className="h-6 w-6" />
                      )}
                    </div>
                    {i < stages.length - 1 && (
                      <div className={`mt-2 h-12 w-0.5 rounded-full ${isComplete ? 'bg-gold' : 'bg-charcoal/10'}`} />
                    )}
                  </div>
                  {/* Text */}
                  <div className="pt-2">
                    <p
                      className={`text-sm font-bold transition-colors duration-500 ${
                        isComplete || isActive ? 'text-charcoal' : 'text-charcoal/40'
                      }`}
                    >
                      {stage.label}
                    </p>
                    <p
                      className={`mt-0.5 text-xs transition-colors duration-500 ${
                        isComplete || isActive ? 'text-charcoal/60' : 'text-charcoal/30'
                      }`}
                    >
                      {stage.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
