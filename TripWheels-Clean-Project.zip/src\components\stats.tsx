'use client';

import { useEffect, useRef, useState } from 'react';
import { Star } from 'lucide-react';

const stats = [
  { value: 10000, suffix: '+', label: 'Trips Completed' },
  { value: 2500, suffix: '+', label: 'Verified Drivers' },
  { value: 1000, suffix: '+', label: 'Premium Vehicles' },
  { value: 4.8, suffix: '★', label: 'Average Rating', isRating: true },
];

function useCountUp(target: number, duration: number, start: boolean) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (startTime === null) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(target * eased);
      if (progress < 1) requestAnimationFrame(step);
      else setCount(target);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);

  return count;
}

function StatItem({
  value,
  suffix,
  label,
  isRating,
  start,
}: {
  value: number;
  suffix: string;
  label: string;
  isRating?: boolean;
  start: boolean;
}) {
  const count = useCountUp(value, 2000, start);
  const display = isRating ? count.toFixed(1) : Math.floor(count).toLocaleString();

  return (
    <div className="flex flex-col items-center text-center">
      <div className="flex items-baseline gap-0.5">
        {isRating && <Star className="h-7 w-7 fill-gold text-gold sm:h-8 sm:w-8" />}
        <span className="font-playfair text-4xl font-bold text-white sm:text-5xl md:text-6xl">
          {display}
        </span>
        {!isRating && (
          <span className="font-playfair text-3xl font-bold text-gold sm:text-4xl md:text-5xl">
            {suffix}
          </span>
        )}
        {isRating && (
          <span className="font-playfair text-3xl font-bold text-gold sm:text-4xl md:text-5xl">
            {suffix}
          </span>
        )}
      </div>
      <span className="mt-3 text-sm font-medium uppercase tracking-wider text-white/60 sm:text-base">
        {label}
      </span>
    </div>
  );
}

export function Stats() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden bg-charcoal-gradient py-20 sm:py-28"
    >
      {/* Decorative gold lines */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />

      {/* Decorative glow */}
      <div className="absolute top-1/2 left-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/5 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold">
            Trusted by Thousands
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-white sm:text-4xl md:text-5xl">
            Numbers That Speak for Us
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4 lg:gap-12">
          {stats.map((stat) => (
            <StatItem
              key={stat.label}
              value={stat.value}
              suffix={stat.suffix}
              label={stat.label}
              isRating={stat.isRating}
              start={visible}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
