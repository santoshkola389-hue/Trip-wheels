'use client';

import {
  ShieldCheck,
  BadgeCheck,
  UserCheck,
  Sparkles,
  Headphones,
  CreditCard,
} from 'lucide-react';

const safetyFeatures = [
  {
    icon: UserCheck,
    title: 'Verified Drivers',
    description:
      'Every driver undergoes a thorough background check, license verification, and in-person interview before joining our network.',
  },
  {
    icon: ShieldCheck,
    title: 'Safe & Sanitized',
    description:
      'All vehicles are cleaned and sanitized before each trip. We follow strict hygiene protocols for your peace of mind.',
  },
  {
    icon: BadgeCheck,
    title: 'Trusted Service',
    description:
      'Our drivers are rated by real passengers after every trip. Only top-rated professionals stay on our platform.',
  },
  {
    icon: Sparkles,
    title: 'Premium Vehicles',
    description:
      'A fleet of well-maintained, luxury and comfort-class vehicles — inspected regularly for safety and performance.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description:
      'Our support team is available around the clock. Call or message anytime — before, during, or after your trip.',
  },
  {
    icon: CreditCard,
    title: 'Transparent Pricing',
    description:
      'No hidden charges. You see the full fare upfront before booking. What you see is exactly what you pay.',
  },
];

export function Safety() {
  return (
    <section
      id="safety"
      className="relative bg-gradient-to-b from-white to-charcoal/5 py-20 sm:py-28"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            Safety First
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Your Safety Is Our Priority
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            We go beyond getting you from A to B. Every aspect of your journey
            is designed with safety, trust, and comfort in mind.
          </p>
        </div>

        {/* Verified badges row */}
        <div className="mb-12 flex flex-wrap justify-center gap-4 sm:gap-6">
          {[
            'Background Verified',
            'License Authenticated',
            'GPS Tracked',
            'Insurance Covered',
          ].map((badge) => (
            <div
              key={badge}
              className="flex items-center gap-2 rounded-full border border-gold/30 bg-gold/5 px-4 py-2"
            >
              <BadgeCheck className="h-4 w-4 text-gold-dark" />
              <span className="text-sm font-medium text-charcoal">{badge}</span>
            </div>
          ))}
        </div>

        {/* Feature grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {safetyFeatures.map((feature) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="group rounded-2xl border border-charcoal/8 bg-white p-7 transition-all duration-500 hover:border-gold/50 hover:shadow-charcoal"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gold/10 text-gold-dark transition-all duration-500 group-hover:bg-gold-gradient group-hover:text-charcoal">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="font-playfair text-lg font-bold text-charcoal">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-charcoal/60">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="mt-14 text-center">
          <p className="font-playfair text-xl text-charcoal sm:text-2xl">
            Travel with confidence.{' '}
            <span className="text-gradient-gold font-bold">
              Every single time.
            </span>
          </p>
        </div>
      </div>
    </section>
  );
}
