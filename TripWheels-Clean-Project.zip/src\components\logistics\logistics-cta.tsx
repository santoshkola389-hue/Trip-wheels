'use client';

import { Route, Phone } from 'lucide-react';

export function LogisticsCTA() {
  return (
    <section className="relative overflow-hidden bg-charcoal-gradient py-20 sm:py-28">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
      <div className="absolute top-1/2 left-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/5 blur-3xl" />

      {/* Decorative route lines */}
      <svg className="absolute inset-0 h-full w-full opacity-5" preserveAspectRatio="none">
        <path d="M -50 100 Q 200 50, 400 150 T 900 80" stroke="#c9a84c" strokeWidth="2" fill="none" />
        <path d="M -50 200 Q 300 150, 500 250 T 1000 180" stroke="#c9a84c" strokeWidth="2" fill="none" />
        <path d="M -50 300 Q 250 250, 450 350 T 900 280" stroke="#c9a84c" strokeWidth="2" fill="none" />
      </svg>

      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        {/* Badge */}
        <div className="mb-6 flex justify-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-charcoal/40 px-4 py-1.5 text-xs font-medium text-gold backdrop-blur-sm">
            <Route className="h-3.5 w-3.5" />
            TRIPWHEELS LOGISTICS
          </span>
        </div>

        {/* Heading */}
        <h2 className="font-playfair text-3xl font-bold text-white sm:text-4xl md:text-5xl">
          Planning a Trip?{' '}
          <span className="text-gradient-gold">Let TripWheels Handle the Logistics.</span>
        </h2>

        {/* Text */}
        <p className="mx-auto mt-5 max-w-xl text-base text-white/70 sm:text-lg">
          Tell us where you're going. We'll help arrange the vehicle, driver and
          transportation logistics you need.
        </p>

        {/* Buttons */}
        <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
          <a
            href="#trip-planner"
            className="rounded-lg bg-gold-gradient px-8 py-3.5 text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90"
          >
            Plan My Trip
          </a>
          <a
            href="#footer"
            className="flex items-center justify-center gap-2 rounded-lg border border-white/20 px-8 py-3.5 text-sm font-semibold text-white transition-colors hover:border-gold hover:text-gold"
          >
            <Phone className="h-4 w-4" />
            Talk to TripWheels
          </a>
        </div>
      </div>
    </section>
  );
}
