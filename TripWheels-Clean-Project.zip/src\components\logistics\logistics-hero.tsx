'use client';

import { Car, Navigation, MapPin, Route } from 'lucide-react';
import { RouteVisual } from './route-visual';

export function LogisticsHero() {
  return (
    <section id="logistics" className="relative overflow-hidden bg-charcoal-gradient py-20 sm:py-28">
      {/* Decorative glow */}
      <div className="absolute top-1/2 left-1/4 h-96 w-96 -translate-y-1/2 rounded-full bg-gold/5 blur-3xl" />
      <div className="absolute bottom-0 right-1/4 h-80 w-80 rounded-full bg-gold/5 blur-3xl" />

      {/* Gold lines */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Left: text */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="mb-6 flex justify-center lg:justify-start">
              <span className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-charcoal/40 px-4 py-1.5 text-xs font-medium text-gold backdrop-blur-sm">
                <Route className="h-3.5 w-3.5" />
                TRIPWHEELS LOGISTICS
              </span>
            </div>

            {/* Heading */}
            <h2 className="font-playfair text-3xl font-bold leading-tight text-white sm:text-4xl md:text-5xl">
              Complete Travel Logistics,{' '}
              <span className="text-gradient-gold">All in One Place</span>
            </h2>

            {/* Subheading */}
            <p className="mx-auto mt-5 max-w-lg text-base text-white/70 sm:text-lg lg:mx-0">
              From pickup to drop-off, TripWheels makes your journey simple,
              comfortable, and stress-free.
            </p>

            {/* Feature pills */}
            <div className="mt-8 flex flex-wrap justify-center gap-3 lg:justify-start">
              {[
                { icon: Car, label: 'Car + Driver' },
                { icon: MapPin, label: 'Multi-Stop Trips' },
                { icon: Navigation, label: 'Pickup & Drop' },
                { icon: Route, label: 'Trip Planning' },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/70 transition-colors hover:border-gold/40 hover:text-gold"
                  >
                    <Icon className="h-4 w-4 text-gold" />
                    {item.label}
                  </div>
                );
              })}
            </div>

            {/* CTA */}
            <div className="mt-8 flex justify-center gap-4 lg:justify-start">
              <a
                href="#trip-planner"
                className="rounded-lg bg-gold-gradient px-7 py-3 text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90"
              >
                Plan Your Journey
              </a>
              <a
                href="#logistics-services"
                className="rounded-lg border border-white/20 px-7 py-3 text-sm font-semibold text-white transition-colors hover:border-gold hover:text-gold"
              >
                Explore Services
              </a>
            </div>
          </div>

          {/* Right: route visual */}
          <div className="relative">
            <RouteVisual className="h-80 sm:h-96 w-full" stops={['Guntur', 'Vijayawada', 'Hyderabad']} />
            {/* Floating stats */}
            <div className="absolute -bottom-4 left-4 rounded-xl border border-gold/20 bg-charcoal/90 px-5 py-3 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-gradient">
                  <Navigation className="h-5 w-5 text-charcoal" />
                </div>
                <div>
                  <p className="text-xs text-white/50">Route Distance</p>
                  <p className="text-sm font-bold text-white">~350 km</p>
                </div>
              </div>
            </div>
            <div className="absolute -top-4 right-4 rounded-xl border border-gold/20 bg-charcoal/90 px-5 py-3 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-gradient">
                  <Car className="h-5 w-5 text-charcoal" />
                </div>
                <div>
                  <p className="text-xs text-white/50">Est. Travel Time</p>
                  <p className="text-sm font-bold text-white">~7 hours</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
