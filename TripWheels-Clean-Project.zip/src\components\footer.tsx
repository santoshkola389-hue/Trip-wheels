'use client';

import { Car, Phone, Mail, MapPin, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';
import { Link } from 'wouter';

const footerLinks = {
  Company: [
    { label: 'About Us', href: '/#safety' },
    { label: 'Our Fleet', href: '/cars' },
    { label: 'Client Login', href: '/login' },
    { label: 'Careers', href: '#' },
    { label: 'Press & Media', href: '#' },
  ],
  Services: [
    { label: 'Outstation Trips', href: '/cars' },
    { label: 'Airport Transfers', href: '/cars' },
    { label: 'Local Rentals', href: '/cars' },
    { label: 'Corporate Fleet', href: '/cars' },
    { label: 'Wedding & Events', href: '/cars' },
  ],
  Support: [
    { label: 'Help Center', href: '#' },
    { label: 'Safety Standards', href: '/#safety' },
    { label: 'Contact Us', href: '#footer' },
    { label: 'FAQs', href: '#' },
    { label: 'Terms & Privacy', href: '#' },
  ],
};

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
];

export function Footer() {
  return (
    <footer id="footer" className="relative bg-charcoal-dark text-white">
      {/* Top gold line */}
      <div className="h-px bg-gradient-to-r from-transparent via-gold to-transparent" />

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-5">
          {/* Brand column */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-gradient">
                <Car className="h-5 w-5 text-charcoal" />
              </div>
              <span className="font-playfair text-xl font-bold tracking-wider">
                TRIP<span className="text-gradient-gold">WHEELS</span>
              </span>
            </Link>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/60">
              Premium car rental with trusted professional drivers. Your dedicated
              partner for comfortable, punctual, and executive travel across India.
            </p>

            {/* Contact info */}
            <div className="mt-6 space-y-3">
              <div className="flex items-center gap-3 text-sm text-white/60">
                <Phone className="h-4 w-4 text-gold" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/60">
                <Mail className="h-4 w-4 text-gold" />
                <span>support@tripwheels.com</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/60">
                <MapPin className="h-4 w-4 text-gold" />
                <span>TripWheels Hub, India</span>
              </div>
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <h4 className="font-playfair text-sm font-bold uppercase tracking-wider text-gold">
                {heading}
              </h4>
              <ul className="mt-4 space-y-3">
                {links.map((link) => (
                  <li key={link.label}>
                    {link.href.startsWith('/') ? (
                      <Link
                        href={link.href}
                        className="text-sm text-white/60 transition-colors duration-300 hover:text-gold"
                      >
                        {link.label}
                      </Link>
                    ) : (
                      <a
                        href={link.href}
                        className="text-sm text-white/60 transition-colors duration-300 hover:text-gold"
                      >
                        {link.label}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-6 border-t border-white/10 pt-8 sm:flex-row">
          <p className="text-sm text-white/50">
            &copy; {new Date().getFullYear()} TRIPWHEELS. All rights reserved.
          </p>

          {/* Social links */}
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 text-white/60 transition-all duration-300 hover:border-gold hover:bg-gold-gradient hover:text-charcoal"
                >
                  <Icon className="h-4 w-4" />
                </a>
              );
            })}
          </div>

          {/* Legal */}
          <div className="flex items-center gap-4 text-sm text-white/50">
            <a href="#" className="transition-colors hover:text-gold">
              Privacy Policy
            </a>
            <a href="#" className="transition-colors hover:text-gold">
              Terms & Conditions
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}