'use client';

import {
  Plane,
  MapPin,
  Clock,
  Repeat,
  CalendarDays,
  Crown,
  ArrowRight,
} from 'lucide-react';

const tripTypes = [
  {
    icon: MapPin,
    title: 'Outstation Trips',
    description:
      'Travel between cities in comfort. Pick your car and driver for a smooth one-way or round journey to any destination.',
  },
  {
    icon: Plane,
    title: 'Airport Transfers',
    description:
      'Punctual pickups and drop-offs to and from any airport. Flight tracking included so your driver is always on time.',
  },
  {
    icon: Clock,
    title: 'Local Rentals',
    description:
      'Hourly rentals for meetings, shopping, or city tours. A dedicated driver at your service for as long as you need.',
  },
  {
    icon: Repeat,
    title: 'Round Trips',
    description:
      'Go and return with the same trusted driver. Ideal for weekend getaways and business trips with flexible scheduling.',
  },
  {
    icon: CalendarDays,
    title: 'Multi-Day Trips',
    description:
      'Planning a longer journey? Keep your driver and vehicle for multiple days with customizable itineraries.',
  },
  {
    icon: Crown,
    title: 'Wedding & Events',
    description:
      'Make your special day unforgettable with luxury cars and chauffeurs for weddings, corporate events, and celebrations.',
  },
];

export function TripTypes() {
  return (
    <section
      id="trip-types"
      className="relative bg-white py-20 sm:py-28"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            What We Offer
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Trip Types for Every Journey
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            From quick airport runs to multi-day adventures, we have the
            perfect ride and driver for every occasion.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tripTypes.map((trip, index) => {
            const Icon = trip.icon;
            return (
              <div
                key={trip.title}
                className="group relative overflow-hidden rounded-2xl border border-charcoal/8 bg-white p-8 transition-all duration-500 hover:border-gold hover:shadow-gold"
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                {/* Hover gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-gold/0 to-gold/0 transition-all duration-500 group-hover:from-gold/5 group-hover:to-transparent" />

                {/* Icon */}
                <div className="relative mb-5">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-charcoal text-gold transition-all duration-500 group-hover:bg-gold-gradient group-hover:text-charcoal group-hover:scale-110">
                    <Icon className="h-7 w-7" />
                  </div>
                </div>

                {/* Content */}
                <h3 className="relative font-playfair text-xl font-bold text-charcoal">
                  {trip.title}
                </h3>
                <p className="relative mt-3 text-sm leading-relaxed text-charcoal/60">
                  {trip.description}
                </p>

                {/* Explore link */}
                <a
                  href="#"
                  className="relative mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-gold-dark transition-colors hover:text-charcoal group/link"
                >
                  Explore
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover/link:translate-x-1" />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
