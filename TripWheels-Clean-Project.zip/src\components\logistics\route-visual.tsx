'use client';

import { useEffect, useRef } from 'react';

interface RouteVisualProps {
  className?: string;
  stops?: string[];
}

export function RouteVisual({ className = '', stops = ['Guntur', 'Vijayawada', 'Hyderabad'] }: RouteVisualProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add('animate-route');
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Generate pin positions along a curved path
  const pinCount = stops.length;
  const pins = stops.map((label, i) => {
    const x = 15 + (i * (70 / Math.max(pinCount - 1, 1)));
    const y = 50 + Math.sin((i / Math.max(pinCount - 1, 1)) * Math.PI) * -25;
    return { x, y, label, isFirst: i === 0, isLast: i === pinCount - 1 };
  });

  // Build the path string
  const pathD = pins
    .map((p, i) => {
      if (i === 0) return `M ${p.x} ${p.y}`;
      const prev = pins[i - 1];
      const midX = (prev.x + p.x) / 2;
      const midY = (prev.y + p.y) / 2 - 8;
      return `Q ${midX} ${midY}, ${p.x} ${p.y}`;
    })
    .join(' ');

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden rounded-2xl border border-white/10 bg-charcoal-dark ${className}`}
    >
      {/* Map grid background */}
      <svg
        className="absolute inset-0 h-full w-full opacity-20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#c9a84c" strokeWidth="0.5" />
          </pattern>
          <pattern id="mapGridLarge" width="120" height="120" patternUnits="userSpaceOnUse">
            <path d="M 120 0 L 0 0 0 120" fill="none" stroke="#c9a84c" strokeWidth="0.8" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#mapGrid)" />
        <rect width="100%" height="100%" fill="url(#mapGridLarge)" />
      </svg>

      {/* Decorative road shapes */}
      <svg className="absolute inset-0 h-full w-full opacity-10" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
        <path d="M -20 80 Q 30 60, 50 90 T 120 70" stroke="#c9a84c" strokeWidth="2" fill="none" />
        <path d="M 60 -10 Q 80 40, 50 60 T 90 120" stroke="#c9a84c" strokeWidth="2" fill="none" />
        <circle cx="25" cy="75" r="30" fill="none" stroke="#c9a84c" strokeWidth="1" />
        <circle cx="85" cy="30" r="40" fill="none" stroke="#c9a84c" strokeWidth="1" />
      </svg>

      {/* Main route SVG */}
      <svg
        className="relative h-full w-full"
        viewBox="0 0 100 100"
        preserveAspectRatio="xMidYMid meet"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#c9a84c" stopOpacity="0.4" />
            <stop offset="50%" stopColor="#e0c878" stopOpacity="1" />
            <stop offset="100%" stopColor="#c9a84c" stopOpacity="0.4" />
          </linearGradient>
          <filter id="pinGlow">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Dashed background path */}
        <path
          d={pathD}
          fill="none"
          stroke="#c9a84c"
          strokeWidth="0.8"
          strokeOpacity="0.3"
          strokeDasharray="2 2"
        />

        {/* Animated solid path */}
        <path
          d={pathD}
          fill="none"
          stroke="url(#routeGradient)"
          strokeWidth="1.2"
          strokeLinecap="round"
          style={{
            strokeDasharray: 200,
            strokeDashoffset: 200,
          }}
          className="route-path-anim"
        />

        {/* Location pins */}
        {pins.map((pin, i) => (
          <g key={i} className="route-pin" style={{ animationDelay: `${i * 300 + 500}ms` }}>
            {/* Pulse ring */}
            <circle cx={pin.x} cy={pin.y} r="3" fill="#c9a84c" fillOpacity="0.2" className="route-pulse" />
            {/* Pin outer */}
            <circle cx={pin.x} cy={pin.y} r="2.5" fill={pin.isFirst || pin.isLast ? '#c9a84c' : '#1a1a1a'} stroke="#c9a84c" strokeWidth="0.8" filter="url(#pinGlow)" />
            {/* Pin inner dot */}
            <circle cx={pin.x} cy={pin.y} r="1" fill={pin.isFirst || pin.isLast ? '#1a1a1a' : '#c9a84c'} />
            {/* Label */}
            <text
              x={pin.x}
              y={pin.y + 8}
              textAnchor="middle"
              fill="#ffffff"
              fillOpacity="0.8"
              fontSize="3"
              fontFamily="Inter, sans-serif"
              fontWeight="500"
            >
              {pin.label}
            </text>
          </g>
        ))}

        {/* Moving car indicator */}
        <g className="route-car">
          <circle r="1.5" fill="#e0c878" filter="url(#pinGlow)">
            <animateMotion dur="4s" repeatCount="indefinite" path={pathD} />
          </circle>
        </g>
      </svg>

      <style>{`
        .animate-route .route-path-anim {
          animation: drawPath 2s ease-out forwards;
        }
        @keyframes drawPath {
          to { stroke-dashoffset: 0; }
        }
        .animate-route .route-pin {
          opacity: 0;
          animation: pinAppear 0.5s ease-out forwards;
        }
        @keyframes pinAppear {
          from { opacity: 0; transform: scale(0); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-route .route-pulse {
          animation: pulseRing 2s ease-out infinite;
          transform-origin: center;
          transform-box: fill-box;
        }
        @keyframes pulseRing {
          0% { r: 2.5; opacity: 0.6; }
          100% { r: 6; opacity: 0; }
        }
      `}</style>
    </div>
  );
}
