'use client';

import { useState, useMemo } from 'react';
import {
  MapPin,
  Navigation,
  Calendar,
  Clock,
  Users,
  Car,
  Plus,
  X,
  CheckCircle2,
  Gauge,
  Timer,
  Route as RouteIcon,
  Luggage,
  IndianRupee,
  ArrowRight,
} from 'lucide-react';
import { RouteVisual } from './route-visual';

interface VehicleOption {
  id: string;
  name: string;
  image: string;
  capacity: string;
  luggage: string;
  basePrice: number;
  perKm: number;
}

const vehicleOptions: VehicleOption[] = [
  {
    id: 'sedan',
    name: 'Sedan',
    image: 'https://images.pexels.com/photos/15194849/pexels-photo-15194849.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    capacity: '4 Passengers',
    luggage: '2 Bags',
    basePrice: 500,
    perKm: 12,
  },
  {
    id: 'suv',
    name: 'SUV',
    image: 'https://images.pexels.com/photos/27497571/pexels-photo-27497571.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    capacity: '6 Passengers',
    luggage: '4 Bags',
    basePrice: 800,
    perKm: 18,
  },
  {
    id: 'tempo',
    name: 'Tempo Traveller',
    image: 'https://images.pexels.com/photos/39075475/pexels-photo-39075475.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    capacity: '12 Passengers',
    luggage: '8 Bags',
    basePrice: 1200,
    perKm: 25,
  },
  {
    id: 'minibus',
    name: 'Mini Bus',
    image: 'https://images.pexels.com/photos/18029613/pexels-photo-18029613.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    capacity: '20 Passengers',
    luggage: '15 Bags',
    basePrice: 1800,
    perKm: 35,
  },
];

// Demo distance lookup between cities (in km)
const cityDistances: Record<string, number> = {
  'guntur-vijayawada': 35,
  'guntur-hyderabad': 270,
  'vijayawada-hyderabad': 275,
  'guntur-vizag': 360,
  'hyderabad-vizag': 620,
};

function getDistance(from: string, to: string): number {
  const key = `${from.toLowerCase()}-${to.toLowerCase()}`;
  const reverseKey = `${to.toLowerCase()}-${from.toLowerCase()}`;
  return cityDistances[key] ?? cityDistances[reverseKey] ?? 150;
}

export function TripPlanner() {
  const [pickup, setPickup] = useState('Guntur');
  const [destination, setDestination] = useState('Hyderabad');
  const [travelDate, setTravelDate] = useState('');
  const [pickupTime, setPickupTime] = useState('07:00');
  const [passengers, setPassengers] = useState('4');
  const [selectedVehicle, setSelectedVehicle] = useState('suv');
  const [driverRequired, setDriverRequired] = useState(true);
  const [returnTrip, setReturnTrip] = useState(false);
  const [stops, setStops] = useState<string[]>([]);

  const addStop = () => setStops([...stops, '']);
  const removeStop = (index: number) => setStops(stops.filter((_, i) => i !== index));
  const updateStop = (index: number, value: string) => {
    const newStops = [...stops];
    newStops[index] = value;
    setStops(newStops);
  };

  // Build the route for display
  const routeStops = useMemo(() => {
    const all = [pickup, ...stops.filter((s) => s.trim() !== ''), destination];
    return all.filter((s) => s.trim() !== '');
  }, [pickup, stops, destination]);

  // Calculate estimated cost
  const estimate = useMemo(() => {
    const vehicle = vehicleOptions.find((v) => v.id === selectedVehicle) ?? vehicleOptions[1];
    let totalDistance = 0;
    for (let i = 0; i < routeStops.length - 1; i++) {
      totalDistance += getDistance(routeStops[i], routeStops[i + 1]);
    }
    if (returnTrip) totalDistance *= 2;

    const distanceCost = totalDistance * vehicle.perKm;
    const driverCost = driverRequired ? 500 : 0;
    const stopCost = stops.filter((s) => s.trim() !== '').length * 200;
    const totalCost = vehicle.basePrice + distanceCost + driverCost + stopCost;
    const travelTime = Math.ceil((totalDistance / 50) + stops.filter((s) => s.trim() !== '').length * 0.5);

    return {
      cost: totalCost,
      distance: totalDistance,
      travelTime,
      vehicle: vehicle.name,
      driver: driverRequired ? 'Included' : 'Not Required',
      numStops: stops.filter((s) => s.trim() !== '').length,
    };
  }, [routeStops, selectedVehicle, driverRequired, returnTrip, stops]);

  const vehicle = vehicleOptions.find((v) => v.id === selectedVehicle) ?? vehicleOptions[1];

  return (
    <section id="trip-planner" className="relative bg-gradient-to-b from-white to-charcoal/5 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            Trip Planner
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Plan Your Journey
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            Enter your trip details, choose your vehicle, and get an instant
            estimated cost — all in one place.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-5">
          {/* Form + Vehicle Selection + Cost (left, 3 cols) */}
          <div className="lg:col-span-3 space-y-6">
            {/* Trip form */}
            <div className="rounded-2xl border border-charcoal/8 bg-white p-6 shadow-sm sm:p-8">
              <h3 className="mb-6 font-playfair text-xl font-bold text-charcoal">Trip Details</h3>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {/* Pickup */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Pickup Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                    <input
                      type="text"
                      value={pickup}
                      onChange={(e) => setPickup(e.target.value)}
                      placeholder="Enter pickup city"
                      className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-gold focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Destination */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Destination</label>
                  <div className="relative">
                    <Navigation className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                    <input
                      type="text"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      placeholder="Enter destination city"
                      className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-gold focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Travel Date */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Travel Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none" />
                    <input
                      type="date"
                      value={travelDate}
                      onChange={(e) => setTravelDate(e.target.value)}
                      className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Pickup Time */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Pickup Time</label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none" />
                    <input
                      type="time"
                      value={pickupTime}
                      onChange={(e) => setPickupTime(e.target.value)}
                      className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Passengers */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Number of Passengers</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                    <input
                      type="number"
                      min="1"
                      max="30"
                      value={passengers}
                      onChange={(e) => setPassengers(e.target.value)}
                      className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Vehicle Type (select) */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Vehicle Type</label>
                  <div className="relative">
                    <Car className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none z-10" />
                    <select
                      value={selectedVehicle}
                      onChange={(e) => setSelectedVehicle(e.target.value)}
                      className="h-11 w-full appearance-none rounded-lg border border-charcoal/15 bg-white pl-9 pr-8 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                    >
                      {vehicleOptions.map((v) => (
                        <option key={v.id} value={v.id}>{v.name}</option>
                      ))}
                    </select>
                    <svg className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Toggles */}
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="flex items-center justify-between rounded-lg border border-charcoal/10 bg-charcoal/5 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-charcoal">Driver Required</p>
                    <p className="text-xs text-charcoal/50">Include a professional driver</p>
                  </div>
                  <button
                    onClick={() => setDriverRequired(!driverRequired)}
                    className={`relative h-6 w-11 rounded-full transition-colors ${driverRequired ? 'bg-gold-gradient' : 'bg-charcoal/20'}`}
                  >
                    <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${driverRequired ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between rounded-lg border border-charcoal/10 bg-charcoal/5 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-charcoal">Return Trip</p>
                    <p className="text-xs text-charcoal/50">Round-trip booking</p>
                  </div>
                  <button
                    onClick={() => setReturnTrip(!returnTrip)}
                    className={`relative h-6 w-11 rounded-full transition-colors ${returnTrip ? 'bg-gold-gradient' : 'bg-charcoal/20'}`}
                  >
                    <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${returnTrip ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </button>
                </div>
              </div>

              {/* Stops */}
              <div className="mt-6">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-charcoal/70">
                    Number of Stops: {stops.length}
                  </label>
                  <button
                    onClick={addStop}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-gold/30 bg-gold/5 px-3 py-1.5 text-xs font-semibold text-gold-dark transition-all hover:bg-gold-gradient hover:text-charcoal"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Stop
                  </button>
                </div>

                {/* Stop inputs */}
                {stops.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {stops.map((stop, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-charcoal text-xs font-bold text-gold">
                          {i + 1}
                        </span>
                        <div className="relative flex-1">
                          <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                          <input
                            type="text"
                            value={stop}
                            onChange={(e) => updateStop(i, e.target.value)}
                            placeholder={`Stop ${i + 1} location`}
                            className="h-10 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-gold focus:outline-none transition-colors"
                          />
                        </div>
                        <button
                          onClick={() => removeStop(i)}
                          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-charcoal/15 text-charcoal/50 transition-colors hover:border-red-400 hover:text-red-500"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Route display */}
                {routeStops.length >= 2 && (
                  <div className="mt-4 rounded-lg border border-gold/20 bg-gold/5 px-4 py-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-gold-dark mb-2">Your Route</p>
                    <div className="flex flex-wrap items-center gap-1.5 text-sm font-medium text-charcoal">
                      {routeStops.map((stop, i) => (
                        <span key={i} className="flex items-center gap-1.5">
                          {i > 0 && <ArrowRight className="h-3.5 w-3.5 text-gold-dark" />}
                          <span className={i === 0 || i === routeStops.length - 1 ? 'font-bold' : ''}>
                            {stop || `Stop ${i}`}
                          </span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Vehicle Selection */}
            <div className="rounded-2xl border border-charcoal/8 bg-white p-6 shadow-sm sm:p-8">
              <h3 className="mb-6 font-playfair text-xl font-bold text-charcoal">Select Your Vehicle</h3>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {vehicleOptions.map((v) => {
                  const isSelected = selectedVehicle === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVehicle(v.id)}
                      className={`group relative overflow-hidden rounded-xl border-2 p-4 text-left transition-all duration-300 ${
                        isSelected
                          ? 'border-gold bg-gold/5 shadow-gold'
                          : 'border-charcoal/10 hover:border-gold/40'
                      }`}
                    >
                      {/* Selected checkmark */}
                      {isSelected && (
                        <div className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-gold-gradient">
                          <CheckCircle2 className="h-4 w-4 text-charcoal" />
                        </div>
                      )}

                      {/* Image */}
                      <div className="relative mb-3 h-28 overflow-hidden rounded-lg bg-charcoal/5">
                        <img
                          src={v.image}
                          alt={v.name}
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                      </div>

                      {/* Name */}
                      <h4 className="font-playfair text-base font-bold text-charcoal">{v.name}</h4>

                      {/* Specs */}
                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-charcoal/60">
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3 text-gold-dark" />
                          {v.capacity}
                        </span>
                        <span className="flex items-center gap-1">
                          <Luggage className="h-3 w-3 text-gold-dark" />
                          {v.luggage}
                        </span>
                      </div>

                      {/* Price */}
                      <p className="mt-2 text-sm font-bold text-charcoal">
                        From <IndianRupee className="inline h-3.5 w-3.5" />
                        {v.basePrice.toLocaleString('en-IN')}
                        <span className="text-xs font-normal text-charcoal/50"> + ₹{v.perKm}/km</span>
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Estimated Cost Card */}
            <div className="overflow-hidden rounded-2xl border border-gold/30 bg-charcoal-gradient shadow-charcoal">
              <div className="border-b border-white/10 p-6 sm:p-8">
                <div className="flex items-center gap-2">
                  <IndianRupee className="h-5 w-5 text-gold" />
                  <h3 className="font-playfair text-xl font-bold text-white">Estimated Trip Cost</h3>
                </div>

                {/* Big price */}
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-playfair text-4xl font-bold text-gradient-gold sm:text-5xl">
                    ₹{estimate.cost.toLocaleString('en-IN')}
                  </span>
                  <span className="text-sm text-white/50">estimated total</span>
                </div>

                {/* Details grid */}
                <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <RouteIcon className="h-3.5 w-3.5 text-gold" />
                      Distance
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">~{estimate.distance} km</p>
                  </div>
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <Timer className="h-3.5 w-3.5 text-gold" />
                      Travel Time
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">~{estimate.travelTime} hrs</p>
                  </div>
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <Car className="h-3.5 w-3.5 text-gold" />
                      Vehicle
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">{estimate.vehicle}</p>
                  </div>
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <Users className="h-3.5 w-3.5 text-gold" />
                      Driver
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">{estimate.driver}</p>
                  </div>
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <MapPin className="h-3.5 w-3.5 text-gold" />
                      Stops
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">{estimate.numStops}</p>
                  </div>
                  <div className="rounded-lg border border-white/10 bg-white/5 px-4 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-white/50">
                      <Gauge className="h-3.5 w-3.5 text-gold" />
                      Passengers
                    </div>
                    <p className="mt-1 text-sm font-bold text-white">{passengers}</p>
                  </div>
                </div>

                {/* Trip summary */}
                <div className="mt-4 rounded-lg border border-gold/20 bg-gold/5 px-4 py-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-gold mb-1">Trip Summary</p>
                  <p className="text-sm text-white/80">
                    <span className="font-semibold text-white">{pickup || 'Pickup'}</span>
                    {stops.filter((s) => s.trim()).map((s, i) => (
                      <span key={i}> → <span className="font-semibold text-white">{s}</span></span>
                    ))}
                    {' → '}<span className="font-semibold text-white">{destination || 'Destination'}</span>
                    {returnTrip && <span className="text-gold"> (Round Trip)</span>}
                  </p>
                </div>
              </div>

              {/* Note + button */}
              <div className="p-6 sm:p-8">
                <p className="mb-4 text-xs text-white/50">
                  Final pricing may vary based on distance, vehicle type, trip
                  duration and additional requirements.
                </p>
                <button className="w-full rounded-lg bg-gold-gradient py-3 text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90">
                  Continue Booking
                </button>
              </div>
            </div>
          </div>

          {/* Map visual (right, 2 cols) */}
          <div className="lg:col-span-2">
            <div className="sticky top-24">
              <RouteVisual className="h-64 w-full sm:h-80 lg:h-96" stops={routeStops.length >= 2 ? routeStops.slice(0, 5) : ['Guntur', 'Vijayawada', 'Hyderabad']} />

              {/* Trip info below map */}
              <div className="mt-4 rounded-xl border border-charcoal/8 bg-white p-5 shadow-sm">
                <h4 className="font-playfair text-sm font-bold text-charcoal">Live Route Preview</h4>
                <div className="mt-3 space-y-2.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-charcoal/60">Pickup</span>
                    <span className="font-semibold text-charcoal">{pickup || '—'}</span>
                  </div>
                  {stops.filter((s) => s.trim()).map((s, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span className="text-charcoal/60">Stop {i + 1}</span>
                      <span className="font-semibold text-charcoal">{s}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-charcoal/60">Destination</span>
                    <span className="font-semibold text-charcoal">{destination || '—'}</span>
                  </div>
                  <div className="my-2 h-px bg-charcoal/10" />
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-charcoal/60">Vehicle</span>
                    <span className="font-semibold text-charcoal">{vehicle.name}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-charcoal/60">Date</span>
                    <span className="font-semibold text-charcoal">{travelDate || 'Not set'}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-charcoal/60">Time</span>
                    <span className="font-semibold text-charcoal">{pickupTime}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
