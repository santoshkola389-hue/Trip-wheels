'use client';

import { useState, useEffect } from 'react';
import {
  X,
  Star,
  Users,
  Luggage,
  Fuel,
  Settings,
  Snowflake,
  UserCheck,
  Clock,
  Check,
  ArrowRight,
  MapPin,
  Navigation,
  Calendar,
  Phone,
} from 'lucide-react';
import type { Car } from '@/lib/car-data';

interface CarDetailsModalProps {
  car: Car | null;
  onClose: () => void;
}

type ModalView = 'details' | 'booking' | 'confirmed';

export function CarDetailsModal({ car, onClose }: CarDetailsModalProps) {
  const [view, setView] = useState<ModalView>('details');
  const [includeDriver, setIncludeDriver] = useState(true);

  // Booking form state
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [travelDate, setTravelDate] = useState('');
  const [pickupTime, setPickupTime] = useState('07:00');
  const [passengers, setPassengers] = useState('1');
  const [tripType, setTripType] = useState('outstation');
  const [driverRequired, setDriverRequired] = useState(true);

  useEffect(() => {
    if (car) {
      setView('details');
      setIncludeDriver(true);
      setDriverRequired(true);
    }
  }, [car]);

  useEffect(() => {
    if (!car) return undefined;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, [car]);

  if (!car) return null;

  const handleBook = () => {
    setView('confirmed');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 sm:p-4 md:p-6">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-charcoal-dark/70 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Modal content */}
      <div className="relative z-10 max-h-[100vh] w-full max-w-5xl overflow-y-auto rounded-none bg-white shadow-charcoal animate-scale-in sm:max-h-[90vh] sm:rounded-2xl md:max-h-[85vh]">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-charcoal shadow-md transition-colors hover:bg-gold hover:text-charcoal"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {/* === DETAILS VIEW === */}
        {view === 'details' && (
          <div>
            {/* Hero image */}
            <div className="relative h-56 overflow-hidden bg-charcoal/5 sm:h-72 md:h-80">
              <img
                src={car.image}
                alt={car.name}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-dark/60 to-transparent" />
              {/* Name overlay */}
              <div className="absolute bottom-4 left-5 right-5">
                <div className="mb-1 flex items-center gap-2">
                  <span className="rounded-md bg-gold-gradient px-2.5 py-0.5 text-xs font-semibold text-charcoal">
                    {car.category}
                  </span>
                  <span className="flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-0.5 text-xs font-bold text-charcoal">
                    <Star className="h-3 w-3 fill-gold text-gold" />
                    {car.rating}
                  </span>
                </div>
                <h2 className="font-playfair text-2xl font-bold text-white sm:text-3xl">
                  {car.name}
                </h2>
              </div>
            </div>

            <div className="p-5 sm:p-6 md:p-8">
              {/* Price */}
              <div className="mb-6 flex items-baseline gap-2">
                <span className="text-sm text-charcoal/50">Starting from</span>
                <span className="font-playfair text-3xl font-bold text-charcoal">
                  &#8377;{car.price.toLocaleString('en-IN')}
                </span>
                <span className="text-sm text-charcoal/50">/day</span>
              </div>

              {/* Specs grid */}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  { icon: Users, label: 'Seating', value: `${car.seats} Seats` },
                  { icon: Luggage, label: 'Luggage', value: `${car.luggage} Bags` },
                  { icon: Fuel, label: 'Fuel', value: car.fuel },
                  { icon: Settings, label: 'Transmission', value: car.transmission },
                  { icon: Snowflake, label: 'AC', value: car.ac ? 'Yes' : 'No' },
                  { icon: UserCheck, label: 'Driver', value: 'Available' },
                  { icon: Clock, label: 'Min. Booking', value: car.minBookingDuration },
                  { icon: Star, label: 'Rating', value: `${car.rating} / 5` },
                ].map((spec) => {
                  const Icon = spec.icon;
                  return (
                    <div
                      key={spec.label}
                      className="rounded-xl border border-charcoal/8 bg-charcoal/5 p-3"
                    >
                      <div className="flex items-center gap-1.5 text-xs text-charcoal/50">
                        <Icon className="h-3.5 w-3.5 text-gold-dark" />
                        {spec.label}
                      </div>
                      <p className="mt-1 text-sm font-semibold text-charcoal">
                        {spec.value}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* About this Car */}
              <div className="mt-8">
                <h3 className="font-playfair text-lg font-bold text-charcoal">
                  About this Car
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-charcoal/70">
                  {car.about}
                </p>
              </div>

              {/* Why Choose This Car */}
              <div className="mt-8">
                <h3 className="font-playfair text-lg font-bold text-charcoal">
                  Why Choose This Car
                </h3>
                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {car.whyChoose.map((reason) => (
                    <div
                      key={reason}
                      className="flex items-start gap-2 text-sm text-charcoal/70"
                    >
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" />
                      {reason}
                    </div>
                  ))}
                </div>
              </div>

              {/* Available for */}
              <div className="mt-8">
                <h3 className="font-playfair text-lg font-bold text-charcoal">
                  Available for
                </h3>
                <div className="mt-3 flex flex-wrap gap-2">
                  {car.availableFor.map((useCase) => (
                    <span
                      key={useCase}
                      className="rounded-full border border-gold/20 bg-gold/5 px-3 py-1.5 text-xs font-medium text-charcoal"
                    >
                      {useCase}
                    </span>
                  ))}
                </div>
              </div>

              {/* Driver Option */}
              <div className="mt-8 rounded-xl border border-gold/30 bg-gold/5 p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-playfair text-base font-bold text-charcoal">
                      Add Professional Driver
                    </h3>
                    <p className="mt-1 text-sm text-charcoal/60">
                      {includeDriver
                        ? 'Professional TripWheels driver included'
                        : 'Drive it yourself — self-drive option'}
                    </p>
                  </div>
                  <button
                    onClick={() => setIncludeDriver(!includeDriver)}
                    className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${includeDriver ? 'bg-gold-gradient' : 'bg-charcoal/20'}`}
                  >
                    <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-transform ${includeDriver ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
                </div>
                {includeDriver && (
                  <div className="mt-3 flex items-center gap-2 rounded-lg bg-charcoal/5 px-3 py-2">
                    <UserCheck className="h-4 w-4 text-gold-dark" />
                    <span className="text-xs font-medium text-charcoal/70">
                      Verified, experienced driver included with every TripWheels booking
                    </span>
                  </div>
                )}
              </div>

              {/* Book button */}
              <button
                onClick={() => setView('booking')}
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-gold-gradient py-3.5 text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90"
              >
                Book This Car
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* === BOOKING VIEW === */}
        {view === 'booking' && (
          <div className="p-5 sm:p-6 md:p-8">
            {/* Back link */}
            <button
              onClick={() => setView('details')}
              className="mb-4 flex items-center gap-1 text-sm font-medium text-charcoal/60 transition-colors hover:text-gold-dark"
            >
              <ArrowRight className="h-4 w-4 rotate-180" />
              Back to car details
            </button>

            {/* Header */}
            <div className="mb-6">
              <h2 className="font-playfair text-2xl font-bold text-charcoal">
                Book Your Trip
              </h2>
              <p className="mt-1 text-sm text-charcoal/60">
                {car.name} • {car.category} • &#8377;{car.price.toLocaleString('en-IN')}/day
              </p>
            </div>

            {/* Form */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {/* Pickup */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Pickup Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                  <input
                    type="text"
                    value={pickup}
                    onChange={(e) => setPickup(e.target.value)}
                    placeholder="Enter pickup city"
                    className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Destination */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Destination
                </label>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark" />
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Enter destination city"
                    className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Travel Date */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Travel Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none" />
                  <input
                    type="date"
                    value={travelDate}
                    onChange={(e) => setTravelDate(e.target.value)}
                    className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Pickup Time */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Pickup Time
                </label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none" />
                  <input
                    type="time"
                    value={pickupTime}
                    onChange={(e) => setPickupTime(e.target.value)}
                    className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Passengers */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Number of Passengers
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none" />
                  <input
                    type="number"
                    min="1"
                    max={car.seats}
                    value={passengers}
                    onChange={(e) => setPassengers(e.target.value)}
                    className="h-11 w-full rounded-lg border border-charcoal/15 bg-white pl-9 pr-3 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Trip Type */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                  Trip Type
                </label>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-dark pointer-events-none z-10" />
                  <select
                    value={tripType}
                    onChange={(e) => setTripType(e.target.value)}
                    className="h-11 w-full appearance-none rounded-lg border border-charcoal/15 bg-white pl-9 pr-8 text-sm text-charcoal focus:border-gold focus:outline-none transition-colors"
                  >
                    <option value="outstation">Outstation Trip</option>
                    <option value="local">Local Trip</option>
                    <option value="airport">Airport Transfer</option>
                    <option value="round">Round Trip</option>
                    <option value="multistop">Multi-Stop Trip</option>
                  </select>
                  <svg className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Driver Required toggle */}
            <div className="mt-4 flex items-center justify-between rounded-lg border border-charcoal/10 bg-charcoal/5 px-4 py-3">
              <div>
                <p className="text-sm font-medium text-charcoal">Driver Required</p>
                <p className="text-xs text-charcoal/50">Include a professional TripWheels driver</p>
              </div>
              <button
                onClick={() => setDriverRequired(!driverRequired)}
                className={`relative h-6 w-11 rounded-full transition-colors ${driverRequired ? 'bg-gold-gradient' : 'bg-charcoal/20'}`}
              >
                <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${driverRequired ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {/* Cost summary */}
            <div className="mt-6 rounded-xl border border-gold/30 bg-gold/5 p-5">
              <div className="flex items-center justify-between">
                <span className="text-sm text-charcoal/60">Base Price</span>
                <span className="text-sm font-semibold text-charcoal">&#8377;{car.price.toLocaleString('en-IN')}</span>
              </div>
              {driverRequired && (
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-sm text-charcoal/60">Driver Fee</span>
                  <span className="text-sm font-semibold text-charcoal">&#8377;500</span>
                </div>
              )}
              <div className="mt-3 border-t border-gold/20 pt-3 flex items-center justify-between">
                <span className="text-sm font-bold text-charcoal">Estimated Total</span>
                <span className="font-playfair text-xl font-bold text-charcoal">
                  &#8377;{(car.price + (driverRequired ? 500 : 0)).toLocaleString('en-IN')}
                </span>
              </div>
              <p className="mt-2 text-xs text-charcoal/50">
                Final pricing may vary based on distance, trip duration and additional requirements.
              </p>
            </div>

            {/* Book button */}
            <button
              onClick={handleBook}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-gold-gradient py-3.5 text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90"
            >
              Confirm Booking
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* === CONFIRMED VIEW === */}
        {view === 'confirmed' && (
          <div className="flex flex-col items-center justify-center p-8 py-16 text-center sm:p-12 sm:py-20">
            {/* Success icon */}
            <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gold-gradient animate-pulse-gold">
              <Check className="h-10 w-10 text-charcoal" />
            </div>

            <h2 className="font-playfair text-2xl font-bold text-charcoal sm:text-3xl">
              Booking Confirmed!
            </h2>
            <p className="mt-3 max-w-md text-sm text-charcoal/60">
              Your {car.name} has been booked for your trip. A TripWheels team
              member will contact you shortly to confirm the details.
            </p>

            {/* Booking summary */}
            <div className="mt-8 w-full max-w-md rounded-xl border border-charcoal/8 bg-charcoal/5 p-5 text-left">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-charcoal/50">Booking ID</span>
                  <span className="text-sm font-bold text-charcoal">TW{Math.floor(Math.random() * 900000 + 100000)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-charcoal/50">Vehicle</span>
                  <span className="text-sm font-semibold text-charcoal">{car.name}</span>
                </div>
                {pickup && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/50">Pickup</span>
                    <span className="text-sm font-semibold text-charcoal">{pickup}</span>
                  </div>
                )}
                {destination && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/50">Destination</span>
                    <span className="text-sm font-semibold text-charcoal">{destination}</span>
                  </div>
                )}
                {travelDate && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-charcoal/50">Date</span>
                    <span className="text-sm font-semibold text-charcoal">{travelDate}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-charcoal/50">Time</span>
                  <span className="text-sm font-semibold text-charcoal">{pickupTime}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-charcoal/50">Driver</span>
                  <span className="text-sm font-semibold text-charcoal">
                    {driverRequired ? 'Included' : 'Not Required'}
                  </span>
                </div>
                <div className="border-t border-charcoal/10 pt-3 flex items-center justify-between">
                  <span className="text-xs font-bold text-charcoal">Total</span>
                  <span className="font-playfair text-lg font-bold text-charcoal">
                    &#8377;{(car.price + (driverRequired ? 500 : 0)).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button className="flex items-center justify-center gap-2 rounded-lg border border-charcoal/15 px-6 py-3 text-sm font-semibold text-charcoal transition-all hover:border-gold hover:bg-gold/5">
                <Phone className="h-4 w-4 text-gold-dark" />
                Contact Support
              </button>
              <button
                onClick={onClose}
                className="flex items-center justify-center gap-2 rounded-lg bg-gold-gradient px-6 py-3 text-sm font-semibold text-charcoal transition-opacity hover:opacity-90"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
