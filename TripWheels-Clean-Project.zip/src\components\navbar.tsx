'use client';

import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { Menu, X, Car, LogOut, User } from 'lucide-react';
import { useAuth } from '@/components/auth-provider';

const navLinks = [
  { label: 'Home', href: '/#home' },
  { label: 'Trip Types', href: '/#trip-types' },
  { label: 'Logistics', href: '/#logistics' },
  { label: 'Why Us', href: '/#safety' },
  { label: 'Cars', href: '/cars' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, signOut } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setMobileOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'glass-dark py-3 shadow-charcoal'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group" data-testid="link-brand-home">
          <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gold bg-gold-gradient transition-transform duration-300 group-hover:scale-110">
            <Car className="h-5 w-5 text-charcoal" />
          </div>
          <span className="font-playfair text-xl font-bold tracking-wider text-white">
            TRIP<span className="text-gradient-gold">WHEELS</span>
          </span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <li key={link.label}>
              <a
                href={link.href}
                className="text-sm font-medium text-white/80 transition-colors duration-300 hover:text-gold"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTA + Sign in / User Profile */}
        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md rounded-full pl-2 pr-3 py-1.5 border border-white/20 shadow-sm">
              <img
                src={user.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.fullName || user.email)}`}
                alt="Avatar"
                className="h-7 w-7 rounded-full object-cover border border-gold"
              />
              <span className="text-xs font-semibold text-white">
                Hi, {user.fullName || user.email.split('@')[0]}
              </span>
              <button
                onClick={handleSignOut}
                className="flex h-6 w-6 items-center justify-center rounded-full text-white/60 hover:text-red-400 transition-colors ml-1 cursor-pointer"
                aria-label="Sign out"
                title="Sign out"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="inline-flex h-10 items-center gap-1.5 justify-center rounded-lg border border-white/25 bg-white/10 px-4 text-sm font-medium text-white backdrop-blur-sm transition-all hover:bg-white/20 hover:border-gold hover:text-gold cursor-pointer"
            >
              <User className="h-4 w-4" />
              Sign In
            </Link>
          )}

          <Link
            href="/cars"
            data-testid="link-book-now"
            className="inline-flex h-10 items-center justify-center rounded-lg bg-gold-gradient px-5 text-sm font-semibold text-charcoal transition-opacity duration-300 hover:opacity-90 shadow-md cursor-pointer"
          >
            Book Now
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="text-white md:hidden cursor-pointer"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden glass-dark mt-3 mx-4 rounded-xl border border-white/10 p-6 animate-slide-down">
          <ul className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <li key={link.label}>
                <a
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="block text-sm font-medium text-white/80 transition-colors hover:text-gold"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <Link
                href="/cars"
                data-testid="link-mobile-book-now"
                className="flex w-full items-center justify-center rounded-lg bg-gold-gradient py-3 text-sm font-semibold text-charcoal"
              >
                Book Now
              </Link>
            </li>
            
            {user ? (
              <li className="flex items-center justify-between p-3 rounded-lg bg-white/10 border border-white/15">
                <div className="flex items-center gap-2.5">
                  <img
                    src={user.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.fullName || user.email)}`}
                    alt="Avatar"
                    className="h-8 w-8 rounded-full object-cover border border-gold"
                  />
                  <div>
                    <div className="text-sm font-semibold text-white">
                      {user.fullName || user.email.split('@')[0]}
                    </div>
                    <div className="text-xs text-white/60">
                      {user.email}
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1.5 text-xs font-medium text-red-300 hover:text-red-200 cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                  Sign Out
                </button>
              </li>
            ) : (
              <li>
                <Link
                  href="/login"
                  onClick={() => setMobileOpen(false)}
                  className="flex w-full items-center justify-center gap-2 rounded-lg border border-white/20 py-2.5 text-sm font-medium text-white hover:border-gold hover:text-gold transition-colors"
                >
                  <User className="h-4 w-4" />
                  Sign In
                </Link>
              </li>
            )}
          </ul>
        </div>
      )}
    </header>
  );
}