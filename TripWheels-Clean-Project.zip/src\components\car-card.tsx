'use client';

import { Star, Users, Fuel, Settings, ArrowRight } from 'lucide-react';
import type { Car } from '@/lib/car-data';

interface CarCardProps {
  car: Car;
  onViewDetails: (car: Car) => void;
}

export function CarCard({ car, onViewDetails }: CarCardProps) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-charcoal/8 bg-white transition-all duration-500 hover:border-gold/50 hover:shadow-charcoal">
      {/* Image */}
      <div className="relative h-44 overflow-hidden bg-charcoal/5">
        <img
          src={car.image}
          alt={car.name}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Category tag */}
        <div className="absolute bottom-3 left-3 rounded-md bg-charcoal/90 px-2.5 py-1 text-xs font-semibold text-gold backdrop-blur-sm">
          {car.category}
        </div>
        {/* Rating badge */}
        <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-1 text-xs font-bold text-charcoal shadow-sm">
          <Star className="h-3 w-3 fill-gold text-gold" />
          {car.rating}
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-5">
        {/* Name */}
        <h3 className="font-playfair text-lg font-bold text-charcoal">
          {car.name}
        </h3>

        {/* Specs row */}
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-charcoal/60">
          <span className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5 text-gold-dark" />
            {car.seats} Seats
          </span>
          <span className="flex items-center gap-1">
            <Fuel className="h-3.5 w-3.5 text-gold-dark" />
            {car.fuel}
          </span>
          <span className="flex items-center gap-1">
            <Settings className="h-3.5 w-3.5 text-gold-dark" />
            {car.transmission}
          </span>
        </div>

        {/* Price */}
        <div className="mt-4 flex items-baseline gap-1">
          <span className="text-xs text-charcoal/50">Starting from</span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="font-playfair text-2xl font-bold text-charcoal">
            &#8377;{car.price.toLocaleString('en-IN')}
          </span>
          <span className="text-xs text-charcoal/50">/day</span>
        </div>

        {/* View Details button */}
        <button
          onClick={() => onViewDetails(car)}
          className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-charcoal/15 px-5 py-2.5 text-sm font-semibold text-charcoal transition-all duration-300 hover:border-gold hover:bg-gold-gradient hover:text-charcoal"
        >
          View Details
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </div>
  );
}
