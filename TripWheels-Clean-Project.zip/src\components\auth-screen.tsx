'use client';

import { useState, FormEvent } from 'react';
import {
  Car,
  Mail,
  Lock,
  Eye,
  EyeOff,
  User,
  Phone,
  ArrowLeft,
  Check,
  Loader2,
  Route,
  MapPin,
  Navigation,
  ShieldCheck,
} from 'lucide-react';
import { isSupabaseConfigured, supabase } from '@/lib/supabase-client';

type View = 'signin' | 'signup' | 'forgot';

const PROMO_IMAGE_URL =
  'https://images.pexels.com/photos/1405665/pexels-photo-1405665.jpeg?auto=compress&cs=tinysrgb&w=1920';

export function AuthScreen() {
  const [view, setView] = useState<View>('signin');

  // Sign in state
  const [signinEmail, setSigninEmail] = useState('');
  const [signinPassword, setSigninPassword] = useState('');
  const [showSigninPassword, setShowSigninPassword] = useState(false);

  // Sign up state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirm, setSignupConfirm] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);

  // Forgot password state
  const [forgotEmail, setForgotEmail] = useState('');

  // Shared state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  // === SIGN IN ===
  const handleSignIn = async (e: FormEvent) => {
    e.preventDefault();
    setErrors({});
    setSuccessMessage('');

    const newErrors: Record<string, string> = {};
    if (!signinEmail) newErrors.email = 'Please enter your email address';
    else if (!validateEmail(signinEmail)) newErrors.email = 'Please enter a valid email address';
    if (!signinPassword) newErrors.password = 'Please enter your password';
    else if (signinPassword.length < 8) newErrors.password = 'Password must be at least 8 characters';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    if (!supabase || !isSupabaseConfigured) {
      setErrors({ form: 'Authentication is not configured in this preview. You can continue browsing without an account.' });
      return;
    }

    setSubmitting(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: signinEmail,
      password: signinPassword,
    });
    setSubmitting(false);

    if (error) {
      setErrors({ form: error.message });
    }
  };

  // === SIGN UP ===
  const handleSignUp = async (e: FormEvent) => {
    e.preventDefault();
    setErrors({});
    setSuccessMessage('');

    const newErrors: Record<string, string> = {};
    if (!signupName) newErrors.name = 'Please enter your full name';
    if (!signupEmail) newErrors.email = 'Please enter your email address';
    else if (!validateEmail(signupEmail)) newErrors.email = 'Please enter a valid email address';
    if (!signupPhone) newErrors.phone = 'Please enter your mobile number';
    else if (signupPhone.replace(/\D/g, '').length < 10) newErrors.phone = 'Please enter a valid mobile number';
    if (!signupPassword) newErrors.password = 'Please enter a password';
    else if (signupPassword.length < 8) newErrors.password = 'Password must be at least 8 characters';
    if (signupConfirm !== signupPassword) newErrors.confirm = 'Passwords do not match';
    if (!agreeTerms) newErrors.terms = 'Please accept the Terms & Conditions';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    if (!supabase || !isSupabaseConfigured) {
      setErrors({ form: 'Authentication is not configured in this preview. You can continue browsing without an account.' });
      return;
    }

    setSubmitting(true);
    const { error } = await supabase.auth.signUp({
      email: signupEmail,
      password: signupPassword,
      options: {
        data: {
          full_name: signupName,
          phone: signupPhone,
        },
      },
    });
    setSubmitting(false);

    if (error) {
      setErrors({ form: error.message });
    } else {
      setSuccessMessage('Account created successfully! You are now signed in.');
    }
  };

  // === FORGOT PASSWORD ===
  const handleForgot = async (e: FormEvent) => {
    e.preventDefault();
    setErrors({});
    setSuccessMessage('');

    const newErrors: Record<string, string> = {};
    if (!forgotEmail) newErrors.email = 'Please enter your email address';
    else if (!validateEmail(forgotEmail)) newErrors.email = 'Please enter a valid email address';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    if (!supabase || !isSupabaseConfigured) {
      setErrors({ form: 'Password recovery is unavailable until authentication is configured.' });
      return;
    }

    setSubmitting(true);
    const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail);
    setSubmitting(false);

    if (error) {
      setErrors({ form: error.message });
    } else {
      setSuccessMessage('Password reset link sent! Check your email.');
    }
  };

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* === LEFT SIDE — AUTH FORM === */}
      <div className="flex w-full flex-col justify-center bg-white px-6 py-8 sm:px-10 lg:w-[45%] lg:px-16 lg:py-0 xl:px-20">
        <div className="mx-auto w-full max-w-md">
          {/* Logo */}
          <div className="mb-8 flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gold bg-gold-gradient">
              <Car className="h-5 w-5 text-charcoal" />
            </div>
            <span className="font-playfair text-xl font-bold tracking-wider text-charcoal">
              TRIP<span className="text-gradient-gold">WHEELS</span>
            </span>
          </div>

          {/* === SIGN IN === */}
          {view === 'signin' && (
            <div className="animate-fade-in">
              <h1 className="font-playfair text-2xl font-bold text-charcoal sm:text-3xl">
                WELCOME BACK!
              </h1>
              <p className="mt-2 text-sm text-charcoal/60">
                Sign in to your TripWheels account and continue your journey.
              </p>

              <form onSubmit={handleSignIn} className="mt-8 space-y-5">
                {/* Email */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="email"
                      value={signinEmail}
                      onChange={(e) => setSigninEmail(e.target.value)}
                      placeholder="Enter your email"
                      className={`h-12 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.email ? 'border-red-400 focus:border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>

                {/* Password */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type={showSigninPassword ? 'text' : 'password'}
                      value={signinPassword}
                      onChange={(e) => setSigninPassword(e.target.value)}
                      placeholder="Enter your password"
                      className={`h-12 w-full rounded-lg border bg-white pl-10 pr-10 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.password ? 'border-red-400 focus:border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowSigninPassword(!showSigninPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-charcoal/40 transition-colors hover:text-charcoal"
                    >
                      {showSigninPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {errors.password && <p className="mt-1 text-xs text-red-500">{errors.password}</p>}
                </div>

                {/* Forgot password */}
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => { setView('forgot'); setErrors({}); }}
                    className="text-xs font-medium text-gold-dark transition-colors hover:text-charcoal"
                  >
                    Forgot Password?
                  </button>
                </div>

                {/* Form error */}
                {errors.form && (
                  <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-600">
                    {errors.form}
                  </div>
                )}

                {/* Sign in button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-charcoal-gradient text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-60"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    'SIGN IN'
                  )}
                </button>
              </form>

              {/* Divider */}
              <div className="my-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-charcoal/10" />
                <span className="text-xs text-charcoal/40">OR</span>
                <div className="h-px flex-1 bg-charcoal/10" />
              </div>

              {/* Social login */}
              <div className="space-y-3">
                 <button type="button" onClick={() => setErrors({ form: 'Google sign-in is unavailable until authentication is configured.' })} className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-charcoal/15 text-sm font-medium text-charcoal transition-colors hover:border-gold/50 hover:bg-charcoal/5">
                  <svg className="h-4 w-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                  </svg>
                  Continue with Google
                </button>
                 <button type="button" onClick={() => setErrors({ form: 'Apple sign-in is unavailable until authentication is configured.' })} className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-charcoal/15 text-sm font-medium text-charcoal transition-colors hover:border-gold/50 hover:bg-charcoal/5">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
                  </svg>
                  Continue with Apple
                </button>
              </div>

              {/* Sign up link */}
              <p className="mt-8 text-center text-sm text-charcoal/60">
                Don't have an account?{' '}
                <button
                  onClick={() => { setView('signup'); setErrors({}); }}
                  className="font-bold text-gold-dark transition-colors hover:text-charcoal"
                >
                  SIGN UP
                </button>
              </p>
            </div>
          )}

          {/* === SIGN UP === */}
          {view === 'signup' && (
            <div className="animate-fade-in">
              <h1 className="font-playfair text-2xl font-bold text-charcoal sm:text-3xl">
                CREATE YOUR TRIPWHEELS ACCOUNT
              </h1>
              <p className="mt-2 text-sm text-charcoal/60">
                Join TripWheels and make your journeys easier.
              </p>

              <form onSubmit={handleSignUp} className="mt-6 space-y-4">
                {/* Full Name */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="text"
                      value={signupName}
                      onChange={(e) => setSignupName(e.target.value)}
                      placeholder="Enter your full name"
                      className={`h-11 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.name ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
                </div>

                {/* Email */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="email"
                      value={signupEmail}
                      onChange={(e) => setSignupEmail(e.target.value)}
                      placeholder="Enter your email"
                      className={`h-11 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.email ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>

                {/* Mobile */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Mobile Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="tel"
                      value={signupPhone}
                      onChange={(e) => setSignupPhone(e.target.value)}
                      placeholder="Enter your mobile number"
                      className={`h-11 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.phone ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.phone && <p className="mt-1 text-xs text-red-500">{errors.phone}</p>}
                </div>

                {/* Password */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type={showSignupPassword ? 'text' : 'password'}
                      value={signupPassword}
                      onChange={(e) => setSignupPassword(e.target.value)}
                      placeholder="Create a password"
                      className={`h-11 w-full rounded-lg border bg-white pl-10 pr-10 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.password ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowSignupPassword(!showSignupPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-charcoal/40 transition-colors hover:text-charcoal"
                    >
                      {showSignupPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {errors.password && <p className="mt-1 text-xs text-red-500">{errors.password}</p>}
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Confirm Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="password"
                      value={signupConfirm}
                      onChange={(e) => setSignupConfirm(e.target.value)}
                      placeholder="Confirm your password"
                      className={`h-11 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.confirm ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.confirm && <p className="mt-1 text-xs text-red-500">{errors.confirm}</p>}
                </div>

                {/* Terms checkbox */}
                <div>
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreeTerms}
                      onChange={(e) => setAgreeTerms(e.target.checked)}
                      className="mt-0.5 h-4 w-4 rounded border-charcoal/30 text-gold-dark focus:ring-gold"
                    />
                    <span className="text-xs text-charcoal/60">
                      I agree to the Terms & Conditions and Privacy Policy
                    </span>
                  </label>
                  {errors.terms && <p className="mt-1 text-xs text-red-500">{errors.terms}</p>}
                </div>

                {/* Form error / success */}
                {errors.form && (
                  <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-600">
                    {errors.form}
                  </div>
                )}
                {successMessage && (
                  <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-2.5 text-xs text-green-600">
                    {successMessage}
                  </div>
                )}

                {/* Create account button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-gold-gradient text-sm font-bold text-charcoal transition-opacity hover:opacity-90 disabled:opacity-60"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Creating account...
                    </>
                  ) : (
                    'CREATE ACCOUNT'
                  )}
                </button>
              </form>

              {/* Sign in link */}
              <p className="mt-6 text-center text-sm text-charcoal/60">
                Already have an account?{' '}
                <button
                  onClick={() => { setView('signin'); setErrors({}); setSuccessMessage(''); }}
                  className="font-bold text-gold-dark transition-colors hover:text-charcoal"
                >
                  SIGN IN
                </button>
              </p>
            </div>
          )}

          {/* === FORGOT PASSWORD === */}
          {view === 'forgot' && (
            <div className="animate-fade-in">
              <h1 className="font-playfair text-2xl font-bold text-charcoal sm:text-3xl">
                RESET YOUR PASSWORD
              </h1>
              <p className="mt-2 text-sm text-charcoal/60">
                Enter your email address and we'll help you reset your password.
              </p>

              <form onSubmit={handleForgot} className="mt-8 space-y-5">
                {/* Email */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-charcoal/70">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal/40" />
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="Enter your email"
                      className={`h-12 w-full rounded-lg border bg-white pl-10 pr-3 text-sm text-charcoal placeholder:text-charcoal/40 focus:outline-none transition-colors ${
                        errors.email ? 'border-red-400' : 'border-charcoal/15 focus:border-gold'
                      }`}
                    />
                  </div>
                  {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>

                {/* Form error / success */}
                {errors.form && (
                  <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-600">
                    {errors.form}
                  </div>
                )}
                {successMessage && (
                  <div className="rounded-lg border border-green-200 bg-green-50 px-4 py-2.5 text-xs text-green-600">
                    {successMessage}
                  </div>
                )}

                {/* Send reset link button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-charcoal-gradient text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-60"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Reset Link'
                  )}
                </button>
              </form>

              {/* Back to sign in */}
              <button
                onClick={() => { setView('signin'); setErrors({}); setSuccessMessage(''); }}
                className="mt-6 flex items-center gap-1.5 text-sm font-medium text-charcoal/60 transition-colors hover:text-gold-dark"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Sign In
              </button>
            </div>
          )}
        </div>
      </div>

      {/* === RIGHT SIDE — PROMO PANEL === */}
      <div className="relative hidden w-full overflow-hidden bg-charcoal-dark lg:block lg:w-[55%]">
        {/* Background image */}
        <img
          src={PROMO_IMAGE_URL}
          alt="Car travelling on a scenic road"
          className="absolute inset-0 h-full w-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-charcoal-dark/85 via-charcoal-dark/70 to-charcoal-dark/85" />

        {/* Decorative route lines */}
        <svg className="absolute inset-0 h-full w-full opacity-10" preserveAspectRatio="none">
          <path d="M -50 200 Q 200 100, 400 250 T 900 150" stroke="#c9a84c" strokeWidth="2" fill="none" strokeDasharray="6 6" />
          <path d="M -50 400 Q 300 300, 500 450 T 1000 350" stroke="#c9a84c" strokeWidth="2" fill="none" strokeDasharray="6 6" />
        </svg>

        {/* Content */}
        <div className="relative flex h-full flex-col justify-center px-12 xl:px-20">
          {/* Decorative pins */}
          <div className="mb-8 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-gradient animate-pulse-gold">
              <MapPin className="h-5 w-5 text-charcoal" />
            </div>
            <div className="h-px flex-1 max-w-[80px] bg-gold/30" />
            <div className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 bg-charcoal/60">
              <Navigation className="h-4 w-4 text-gold" />
            </div>
            <div className="h-px flex-1 max-w-[80px] bg-gold/30" />
            <div className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 bg-charcoal/60">
              <MapPin className="h-4 w-4 text-gold" />
            </div>
          </div>

          <h2 className="font-playfair text-3xl font-bold leading-tight text-white xl:text-4xl">
            Your Journey Starts With{' '}
            <span className="text-gradient-gold">TripWheels</span>
          </h2>

          <p className="mt-4 max-w-md text-base text-white/70">
            Reliable cars, professional drivers, and simple travel — all in one
            place.
          </p>

          {/* Benefits */}
          <div className="mt-10 space-y-4">
            {[
              { icon: Car, label: 'Reliable Vehicles' },
              { icon: ShieldCheck, label: 'Professional Drivers' },
              { icon: Route, label: 'Easy Booking' },
            ].map((benefit) => {
              const Icon = benefit.icon;
              return (
                <div key={benefit.label} className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 backdrop-blur-sm">
                    <Icon className="h-4 w-4 text-gold" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-gold" />
                    <span className="text-sm font-medium text-white/80">{benefit.label}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom tagline */}
          <div className="mt-12 border-t border-white/10 pt-6">
            <p className="font-playfair text-lg text-white/90">
              Travel Better. Travel With{' '}
              <span className="text-gradient-gold font-bold">TripWheels.</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
