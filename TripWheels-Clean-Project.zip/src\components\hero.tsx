'use client';

import { useState } from 'react';
import { Link } from 'wouter';
import { MapPin, Navigation, Calendar, Users, Search, Car } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const HERO_IMAGE_URL =
  'https://images.pexels.com/photos/5063634/pexels-photo-5063634.jpeg?auto=compress&cs=tinysrgb&w=1920';

export function Hero() {
  const [tripType, setTripType] = useState('');

  return (
    <section
      id="home"
      className="relative min-h-screen w-full overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_IMAGE_URL}
          alt="Luxury car on highway at sunset"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal-dark/80 via-charcoal/60 to-charcoal-dark/90" />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal-dark/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-4 pt-28 pb-16 sm:px-6 lg:px-8">
        {/* Badge */}
        <div className="mb-6 animate-fade-in opacity-0" style={{ animationDelay: '100ms' }}>
          <span className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-charcoal/40 px-4 py-1.5 text-xs font-medium text-gold backdrop-blur-sm">
            <Car className="h-3.5 w-3.5" />
            Premium Car Rental with Professional Drivers
          </span>
        </div>

        {/* Headline */}
        <h1 className="font-playfair text-4xl font-bold leading-tight text-white sm:text-5xl md:text-6xl lg:text-7xl animate-fade-up opacity-0 max-w-3xl" style={{ animationDelay: '200ms' }}>
          Your Car. <span className="text-gradient-gold">Your Driver.</span>{' '}
          Your Journey.
        </h1>

        {/* Subheadline */}
        <p className="mt-6 max-w-xl text-base text-white/80 sm:text-lg md:text-xl animate-fade-up opacity-0 leading-relaxed" style={{ animationDelay: '400ms' }}>
          Book premium cars with verified, professional drivers for any
          occasion — outstation trips, airport transfers, local rentals, and
          special events. Safe, reliable, and effortlessly luxurious.
        </p>

        {/* Search Widget */}
        <div className="mt-10 w-full max-w-5xl animate-scale-in opacity-0" style={{ animationDelay: '600ms' }}>
          <div className="glass-dark rounded-2xl border border-white/10 p-4 sm:p-6 shadow-charcoal">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-6">
              {/* Pickup */}
              <div className="lg:col-span-1">
                <label className="mb-1.5 block text-xs font-medium text-gold">
                  Pickup Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" />
                  <input
                    type="text"
                    placeholder="Enter city"
                    className="h-11 w-full rounded-lg border border-white/15 bg-white/5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Destination */}
              <div className="lg:col-span-1">
                <label className="mb-1.5 block text-xs font-medium text-gold">
                  Destination
                </label>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" />
                  <input
                    type="text"
                    placeholder="Enter city"
                    className="h-11 w-full rounded-lg border border-white/15 bg-white/5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Trip Type */}
              <div className="lg:col-span-1">
                <label className="mb-1.5 block text-xs font-medium text-gold">
                  Trip Type
                </label>
                <Select value={tripType} onValueChange={setTripType}>
                  <SelectTrigger className="h-11 border-white/15 bg-white/5 text-white text-sm focus:border-gold">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-charcoal border-white/15 text-white">
                    <SelectItem value="outstation" className="text-white focus:bg-white/10 focus:text-gold">
                      Outstation
                    </SelectItem>
                    <SelectItem value="airport" className="text-white focus:bg-white/10 focus:text-gold">
                      Airport Transfer
                    </SelectItem>
                    <SelectItem value="local" className="text-white focus:bg-white/10 focus:text-gold">
                      Local Rental
                    </SelectItem>
                    <SelectItem value="round" className="text-white focus:bg-white/10 focus:text-gold">
                      Round Trip
                    </SelectItem>
                    <SelectItem value="multi" className="text-white focus:bg-white/10 focus:text-gold">
                      Multi-Day Trip
                    </SelectItem>
                    <SelectItem value="wedding" className="text-white focus:bg-white/10 focus:text-gold">
                      Wedding & Events
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div className="lg:col-span-1">
                <label className="mb-1.5 block text-xs font-medium text-gold">
                  Travel Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50 pointer-events-none" />
                  <input
                    type="date"
                    className="h-11 w-full rounded-lg border border-white/15 bg-white/5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-gold focus:outline-none transition-colors [color-scheme:dark]"
                  />
                </div>
              </div>

              {/* Passengers */}
              <div className="lg:col-span-1">
                <label className="mb-1.5 block text-xs font-medium text-gold">
                  Passengers
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" />
                  <input
                    type="number"
                    min="1"
                    max="20"
                    defaultValue="2"
                    className="h-11 w-full rounded-lg border border-white/15 bg-white/5 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:border-gold focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Button */}
              <div className="flex items-end lg:col-span-1">
                <Link
                  href="/cars"
                  data-testid="link-find-your-ride"
                  className="flex h-11 w-full items-center justify-center rounded-lg bg-gold-gradient text-sm font-semibold text-charcoal shadow-gold transition-opacity hover:opacity-90"
                >
                  <Search className="mr-2 h-4 w-4" />
                  Find Your Ride
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Trust indicators */}
        <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-3 animate-fade-in opacity-0" style={{ animationDelay: '800ms' }}>
          {[
            'Verified Drivers',
            '24/7 Support',
            'Transparent Pricing',
            'Safe & Sanitized',
          ].map((item) => (
            <div key={item} className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-gold" />
              <span className="text-sm text-white/70">{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 animate-float">
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs text-white/50">Scroll to explore</span>
          <div className="h-10 w-6 rounded-full border-2 border-white/30 p-1">
            <div className="mx-auto h-2 w-1 rounded-full bg-gold animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}
