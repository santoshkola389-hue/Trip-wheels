import { Navbar } from '@/components/navbar';
import { Hero } from '@/components/hero';
import { TripTypes } from '@/components/trip-types';
import { Stats } from '@/components/stats';
import { Safety } from '@/components/safety';
import { Footer } from '@/components/footer';
import { LogisticsHero } from '@/components/logistics/logistics-hero';
import { LogisticsServices } from '@/components/logistics/logistics-services';
import { TripPlanner } from '@/components/logistics/trip-planner';
import { TripStatusTracking } from '@/components/logistics/trip-status';
import { LogisticsDashboard } from '@/components/logistics/logistics-dashboard';
import { LogisticsCTA } from '@/components/logistics/logistics-cta';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <TripTypes />
      <Stats />
      <Safety />
      <LogisticsHero />
      <LogisticsServices />
      <TripPlanner />
      <TripStatusTracking />
      <LogisticsDashboard />
      <LogisticsCTA />
      <Footer />
    </main>
  );
}
