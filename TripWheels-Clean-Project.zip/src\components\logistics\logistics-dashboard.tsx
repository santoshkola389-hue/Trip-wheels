'use client';

import {
  Car,
  User,
  MapPin,
  Calendar,
  Clock,
  BadgeCheck,
  Phone,
  MessageSquare,
  Navigation,
  ArrowRight,
} from 'lucide-react';

export function LogisticsDashboard() {
  return (
    <section className="relative bg-gradient-to-b from-charcoal/5 to-white py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            Logistics Dashboard
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Manage Your Trips
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            A preview of your personal TripWheels dashboard — track trips,
            contact drivers, and manage bookings all in one place.
          </p>
        </div>

        {/* Dashboard card */}
        <div className="mx-auto max-w-3xl overflow-hidden rounded-2xl border border-charcoal/10 bg-white shadow-charcoal">
          {/* Dashboard header bar */}
          <div className="flex items-center justify-between border-b border-charcoal/8 bg-charcoal-gradient px-6 py-4 sm:px-8">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gold-gradient">
                <Car className="h-4 w-4 text-charcoal" />
              </div>
              <h3 className="font-playfair text-lg font-bold text-white">My Trip</h3>
            </div>
            <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-gold">
              Booking ID: TW784512
            </span>
          </div>

          {/* Dashboard body */}
          <div className="grid grid-cols-1 gap-6 p-6 sm:grid-cols-2 sm:p-8">
            {/* Left: trip details */}
            <div className="space-y-4">
              <h4 className="font-playfair text-sm font-bold uppercase tracking-wide text-gold-dark">
                Trip Details
              </h4>

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-charcoal/5">
                    <Car className="h-4 w-4 text-gold-dark" />
                  </div>
                  <div>
                    <p className="text-xs text-charcoal/50">Vehicle</p>
                    <p className="text-sm font-semibold text-charcoal">Toyota Innova</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-charcoal/5">
                    <User className="h-4 w-4 text-gold-dark" />
                  </div>
                  <div>
                    <p className="text-xs text-charcoal/50">Driver</p>
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold text-charcoal">Rajesh Kumar</p>
                      <BadgeCheck className="h-3.5 w-3.5 text-gold-dark" />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-charcoal/5">
                    <MapPin className="h-4 w-4 text-gold-dark" />
                  </div>
                  <div>
                    <p className="text-xs text-charcoal/50">Route</p>
                    <p className="text-sm font-semibold text-charcoal">Guntur → Hyderabad</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-charcoal/5">
                    <Calendar className="h-4 w-4 text-gold-dark" />
                  </div>
                  <div>
                    <p className="text-xs text-charcoal/50">Date</p>
                    <p className="text-sm font-semibold text-charcoal">15 Sept 2026</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-charcoal/5">
                    <Clock className="h-4 w-4 text-gold-dark" />
                  </div>
                  <div>
                    <p className="text-xs text-charcoal/50">Time</p>
                    <p className="text-sm font-semibold text-charcoal">7:00 AM</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: status + actions */}
            <div className="space-y-4">
              <h4 className="font-playfair text-sm font-bold uppercase tracking-wide text-gold-dark">
                Current Status
              </h4>

              {/* Status badge */}
              <div className="rounded-xl border border-gold/30 bg-gold/5 p-5">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-gradient animate-pulse-gold">
                    <User className="h-6 w-6 text-charcoal" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-charcoal">Driver Assigned</p>
                    <p className="text-xs text-charcoal/60">Your driver has been allocated</p>
                  </div>
                </div>

                {/* Mini progress */}
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-charcoal/50">
                    <span>Confirmed</span>
                    <span className="font-semibold text-gold-dark">Assigned</span>
                    <span>In Transit</span>
                  </div>
                  <div className="mt-1.5 h-1.5 rounded-full bg-charcoal/10">
                    <div className="h-1.5 w-2/5 rounded-full bg-gold-gradient" />
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="space-y-2">
                <button className="flex w-full items-center justify-between rounded-lg border border-charcoal/15 bg-white px-4 py-3 text-sm font-semibold text-charcoal transition-all hover:border-gold hover:bg-gold/5">
                  <span className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-gold-dark" />
                    View Trip
                  </span>
                  <ArrowRight className="h-4 w-4 text-charcoal/40" />
                </button>

                <button className="flex w-full items-center justify-between rounded-lg border border-charcoal/15 bg-white px-4 py-3 text-sm font-semibold text-charcoal transition-all hover:border-gold hover:bg-gold/5">
                  <span className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gold-dark" />
                    Contact Driver
                  </span>
                  <ArrowRight className="h-4 w-4 text-charcoal/40" />
                </button>

                <button className="flex w-full items-center justify-between rounded-lg bg-gold-gradient px-4 py-3 text-sm font-semibold text-charcoal transition-opacity hover:opacity-90">
                  <span className="flex items-center gap-2">
                    <Navigation className="h-4 w-4" />
                    Track Journey
                  </span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Note */}
        <p className="mt-6 text-center text-xs text-charcoal/40">
          Dashboard preview shown with demo data. Sign up to manage your real
          trips.
        </p>
      </div>
    </section>
  );
}
