export type CarCategory = 'Sedan' | 'SUV' | '7-Seater' | 'Tempo Traveller';
export type FuelType = 'Petrol' | 'Diesel' | 'CNG';
export type Transmission = 'Automatic' | 'Manual';

export interface Car {
  id: number;
  name: string;
  category: CarCategory;
  image: string;
  rating: number;
  seats: number;
  luggage: number;
  fuel: FuelType;
  transmission: Transmission;
  ac: boolean;
  price: number;
  minBookingDuration: string;
  about: string;
  whyChoose: string[];
  availableFor: string[];
}

export const carCategories: CarCategory[] = ['Sedan', 'SUV', '7-Seater', 'Tempo Traveller'];

export const cars: Car[] = [
  {
    id: 1,
    name: 'Maruti Suzuki Dzire',
    category: 'Sedan',
    image:
      'https://images.pexels.com/photos/11501948/pexels-photo-11501948.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.6,
    seats: 4,
    luggage: 2,
    fuel: 'Petrol',
    transmission: 'Manual',
    ac: true,
    price: 1499,
    minBookingDuration: '4 hours',
    about:
      'The Maruti Suzuki Dzire is a reliable and fuel-efficient compact sedan, perfect for small families and daily city travel. Its comfortable interiors and smooth ride make it a popular choice for local and outstation trips alike.',
    whyChoose: [
      'Excellent fuel efficiency for long trips',
      'Comfortable seating for 4 passengers',
      'Compact size ideal for city navigation',
      'Well-maintained and regularly serviced',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Corporate Travel'],
  },
  {
    id: 2,
    name: 'Hyundai Aura',
    category: 'Sedan',
    image:
      'https://images.pexels.com/photos/33149191/pexels-photo-33149191.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.5,
    seats: 4,
    luggage: 2,
    fuel: 'Petrol',
    transmission: 'Manual',
    ac: true,
    price: 1399,
    minBookingDuration: '4 hours',
    about:
      'The Hyundai Aura is a stylish and practical sedan offering a smooth ride with modern features. Ideal for small groups needing comfortable and affordable transportation for city or outstation travel.',
    whyChoose: [
      'Modern interior with premium features',
      'Smooth and quiet ride quality',
      'Great value for money',
      'Perfect for small families',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Family Trips'],
  },
  {
    id: 3,
    name: 'Honda Amaze',
    category: 'Sedan',
    image:
      'https://images.pexels.com/photos/5735089/pexels-photo-5735089.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.7,
    seats: 4,
    luggage: 2,
    fuel: 'Petrol',
    transmission: 'Automatic',
    ac: true,
    price: 1599,
    minBookingDuration: '4 hours',
    about:
      'The Honda Amaze combines reliability with comfort. Its automatic transmission and spacious interior make it a great choice for stress-free travel, whether for business or family trips.',
    whyChoose: [
      'Automatic transmission for effortless driving',
      'Spacious and comfortable interior',
      'Honda reliability and low maintenance',
      'Ideal for business and family travel',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Corporate Travel', 'Family Trips'],
  },
  {
    id: 4,
    name: 'Maruti Suzuki Ertiga',
    category: '7-Seater',
    image:
      'https://images.pexels.com/photos/37029578/pexels-photo-37029578.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.7,
    seats: 7,
    luggage: 4,
    fuel: 'Petrol',
    transmission: 'Manual',
    ac: true,
    price: 1999,
    minBookingDuration: '6 hours',
    about:
      'The Maruti Suzuki Ertiga is a versatile 7-seater MPV perfect for families and small groups. With its spacious cabin and efficient engine, it offers excellent value for outstation and local trips.',
    whyChoose: [
      'Comfortable seating for 7 passengers',
      'Excellent fuel efficiency for a 7-seater',
      'Flexible seating and boot space',
      'Ideal for family trips and group travel',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Family Trips', 'Corporate Travel'],
  },
  {
    id: 5,
    name: 'Kia Carens',
    category: '7-Seater',
    image:
      'https://images.pexels.com/photos/7290399/pexels-photo-7290399.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.8,
    seats: 7,
    luggage: 4,
    fuel: 'Petrol',
    transmission: 'Automatic',
    ac: true,
    price: 2299,
    minBookingDuration: '6 hours',
    about:
      'The Kia Carens is a modern and feature-rich 7-seater with premium interiors and smooth automatic transmission. Perfect for families and corporate groups who want extra comfort on longer journeys.',
    whyChoose: [
      'Premium interior with modern features',
      'Automatic transmission for smooth driving',
      'Comfortable 7-seat configuration',
      'Great for long-distance and corporate travel',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Family Trips', 'Corporate Travel', 'Events'],
  },
  {
    id: 6,
    name: 'Toyota Innova',
    category: '7-Seater',
    image:
      'https://images.pexels.com/photos/32422135/pexels-photo-32422135.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.9,
    seats: 7,
    luggage: 5,
    fuel: 'Diesel',
    transmission: 'Manual',
    ac: true,
    price: 2499,
    minBookingDuration: '8 hours',
    about:
      'The Toyota Innova is the gold standard for comfortable group travel in India. Known for its reliability, spacious interior, and smooth ride, it is the most popular choice for family trips, outstation journeys, and corporate travel.',
    whyChoose: [
      'Most trusted 7-seater in India',
      'Spacious and comfortable for long journeys',
      'Excellent reliability and durability',
      'Perfect for outstation and family trips',
    ],
    availableFor: ['Local Trips', 'Outstation Trips', 'Airport Transfers', 'Family Trips', 'Corporate Travel', 'Events'],
  },
  {
    id: 7,
    name: 'Mahindra Scorpio',
    category: 'SUV',
    image:
      'https://images.pexels.com/photos/29057945/pexels-photo-29057945.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.7,
    seats: 7,
    luggage: 4,
    fuel: 'Diesel',
    transmission: 'Manual',
    ac: true,
    price: 2199,
    minBookingDuration: '6 hours',
    about:
      'The Mahindra Scorpio is a rugged and powerful SUV built for Indian roads. Its commanding driving position and durable build make it ideal for highway trips, rural routes, and group travel.',
    whyChoose: [
      'Powerful diesel engine for highway driving',
      'Rugged build for all road conditions',
      'Commanding road presence and safety',
      'Great for outstation and rural travel',
    ],
    availableFor: ['Outstation Trips', 'Airport Transfers', 'Family Trips', 'Corporate Travel', 'Events'],
  },
  {
    id: 8,
    name: 'Mahindra Bolero',
    category: 'SUV',
    image:
      'https://images.pexels.com/photos/33983105/pexels-photo-33983105.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.5,
    seats: 7,
    luggage: 4,
    fuel: 'Diesel',
    transmission: 'Manual',
    ac: true,
    price: 1799,
    minBookingDuration: '6 hours',
    about:
      'The Mahindra Bolero is a tough and dependable SUV known for its durability on Indian roads. An affordable option for group travel, rural routes, and outstation trips where reliability matters most.',
    whyChoose: [
      'Extremely durable and low maintenance',
      'Affordable pricing for group travel',
      'Handles rough roads with ease',
      'Popular for rural and outstation trips',
    ],
    availableFor: ['Outstation Trips', 'Family Trips', 'Corporate Travel'],
  },
  {
    id: 9,
    name: 'Tempo Traveller',
    category: 'Tempo Traveller',
    image:
      'https://images.pexels.com/photos/39075475/pexels-photo-39075475.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    rating: 4.6,
    seats: 12,
    luggage: 8,
    fuel: 'Diesel',
    transmission: 'Manual',
    ac: true,
    price: 2999,
    minBookingDuration: '8 hours',
    about:
      'The Tempo Traveller is the go-to vehicle for large groups, corporate outings, college trips, and wedding transportation. With seating for up to 12 passengers and ample luggage space, it keeps everyone together comfortably.',
    whyChoose: [
      'Seats up to 12 passengers comfortably',
      'Ample luggage space for group travel',
      'Perfect for corporate and college trips',
      'Keeps large groups together',
    ],
    availableFor: ['Outstation Trips', 'Airport Transfers', 'Corporate Travel', 'Events'],
  },
];
