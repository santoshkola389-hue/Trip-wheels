@echo off
title TripWheels Launcher
echo ===================================================
echo Starting TripWheels Website on your computer...
echo ===================================================
cd /d "C:\Users\santo\TripWheels"
start "" "http://localhost:5173"
call npm run dev
pause
