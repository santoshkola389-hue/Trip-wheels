'use client';

import { SlidersHorizontal, X } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Star } from 'lucide-react';
import type { CarCategory, FuelType } from '@/lib/car-data';
import { carCategories } from '@/lib/car-data';

export interface Filters {
  carTypes: CarCategory[];
  budget: [number, number];
  seating: number[];
  fuelTypes: FuelType[];
  acOnly: boolean;
  minDriverRating: number;
}

interface FilterSidebarProps {
  filters: Filters;
  setFilters: (f: Filters) => void;
  resultCount: number;
  onReset: () => void;
  mobileOpen: boolean;
  setMobileOpen: (v: boolean) => void;
}

const fuelOptions: FuelType[] = ['Petrol', 'Diesel', 'CNG'];
const seatingOptions = [4, 7, 12];
const ratingOptions = [3, 4, 4.5];

export function FilterSidebar({
  filters,
  setFilters,
  resultCount,
  onReset,
  mobileOpen,
  setMobileOpen,
}: FilterSidebarProps) {
  const toggleCarType = (type: CarCategory) => {
    setFilters({
      ...filters,
      carTypes: filters.carTypes.includes(type)
        ? filters.carTypes.filter((t) => t !== type)
        : [...filters.carTypes, type],
    });
  };

  const toggleFuel = (fuel: FuelType) => {
    setFilters({
      ...filters,
      fuelTypes: filters.fuelTypes.includes(fuel)
        ? filters.fuelTypes.filter((f) => f !== fuel)
        : [...filters.fuelTypes, fuel],
    });
  };

  const toggleSeating = (seats: number) => {
    setFilters({
      ...filters,
      seating: filters.seating.includes(seats)
        ? filters.seating.filter((s) => s !== seats)
        : [...filters.seating, seats],
    });
  };

  const sidebarContent = (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-5 w-5 text-gold-dark" />
          <h2 className="font-playfair text-lg font-bold text-charcoal">
            Filters
          </h2>
        </div>
        {mobileOpen && (
          <button
            onClick={() => setMobileOpen(false)}
            className="text-charcoal/60 lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
      )}
      </div>

      {/* Car Type */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-charcoal">Vehicle Category</h3>
        <div className="space-y-2.5">
          {carCategories.map((type) => (
            <div key={type} className="flex items-center space-x-2.5">
              <Checkbox
                id={`type-${type}`}
                checked={filters.carTypes.includes(type)}
                onCheckedChange={() => toggleCarType(type)}
                className="border-charcoal/30 data-[state=checked]:bg-gold-gradient data-[state=checked]:border-gold"
              />
              <label
                htmlFor={`type-${type}`}
                className="cursor-pointer text-sm text-charcoal/70"
              >
                {type}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Budget */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-charcoal">Budget Range</h3>
        <div className="px-1">
          <Slider
            value={filters.budget}
            onValueChange={(val) =>
              setFilters({ ...filters, budget: [val[0], val[1]] as [number, number] })
            }
            min={500}
            max={5000}
            step={100}
            className="my-4"
          />
          <div className="flex items-center justify-between text-sm text-charcoal/70">
            <span>&#8377;{filters.budget[0].toLocaleString('en-IN')}</span>
            <span>&#8377;{filters.budget[1].toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      <Separator />

      {/* Seating Capacity */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-charcoal">
          Seating Capacity
        </h3>
        <div className="flex flex-wrap gap-2">
          {seatingOptions.map((seats) => (
            <button
              key={seats}
              onClick={() => toggleSeating(seats)}
              className={`rounded-lg border px-4 py-2 text-sm font-medium transition-all duration-300 ${
                filters.seating.includes(seats)
                  ? 'border-gold bg-gold-gradient text-charcoal'
                  : 'border-charcoal/15 text-charcoal/70 hover:border-gold/50'
              }`}
            >
              {seats} Seater
            </button>
          ))}
        </div>
      </div>

      <Separator />

      {/* Fuel Type */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-charcoal">Fuel Type</h3>
        <div className="space-y-2.5">
          {fuelOptions.map((fuel) => (
            <div key={fuel} className="flex items-center space-x-2.5">
              <Checkbox
                id={`fuel-${fuel}`}
                checked={filters.fuelTypes.includes(fuel)}
                onCheckedChange={() => toggleFuel(fuel)}
                className="border-charcoal/30 data-[state=checked]:bg-gold-gradient data-[state=checked]:border-gold"
              />
              <label
                htmlFor={`fuel-${fuel}`}
                className="cursor-pointer text-sm text-charcoal/70"
              >
                {fuel}
              </label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* AC Toggle */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-charcoal">AC Only</h3>
          <p className="text-xs text-charcoal/50">Show air-conditioned cars</p>
        </div>
        <Switch
          checked={filters.acOnly}
          onCheckedChange={(checked) =>
            setFilters({ ...filters, acOnly: checked })
          }
          className="data-[state=checked]:bg-gold-gradient"
        />
      </div>

      <Separator />

      {/* Driver Rating */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-charcoal">
          Driver Rating
        </h3>
        <div className="space-y-2.5">
          {ratingOptions.map((rating) => (
            <button
              key={rating}
              onClick={() => setFilters({ ...filters, minDriverRating: rating })}
              className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm transition-all duration-300 ${
                filters.minDriverRating === rating
                  ? 'bg-gold/10 text-charcoal'
                  : 'text-charcoal/70 hover:bg-charcoal/5'
              }`}
            >
              <Star
                className={`h-4 w-4 ${
                  filters.minDriverRating <= rating
                    ? 'fill-gold text-gold'
                    : 'text-charcoal/30'
                }`}
              />
              {rating === 3 ? '3.0 & above' : rating === 4 ? '4.0 & above' : '4.5 & above'}
            </button>
          ))}
        </div>
      </div>

      {/* Reset */}
      <Button
        variant="outline"
        onClick={onReset}
        className="w-full border-charcoal/15 text-charcoal hover:border-gold hover:text-gold-dark"
      >
        Reset All Filters
      </Button>

      <p className="text-center text-xs text-charcoal/50">
        {resultCount} {resultCount === 1 ? 'car' : 'cars'} found
      </p>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 lg:block">
        <div className="sticky top-24 rounded-2xl border border-charcoal/8 bg-white p-6">
          {sidebarContent}
        </div>
      </aside>

      {/* Mobile filter button */}
      <div className="lg:hidden">
        <Button
          onClick={() => setMobileOpen(true)}
          className="fixed bottom-6 right-6 z-40 h-14 w-14 rounded-full bg-gold-gradient p-0 text-charcoal shadow-gold animate-pulse-gold"
          aria-label="Open filters"
        >
          <SlidersHorizontal className="h-5 w-5" />
        </Button>
      </div>

      {/* Mobile sidebar drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-charcoal-dark/60 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          {/* Drawer */}
          <div className="absolute bottom-0 left-0 right-0 max-h-[85vh] overflow-y-auto rounded-t-3xl bg-white p-6 animate-slide-down">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
