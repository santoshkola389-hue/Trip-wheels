'use client';

import {
  Car,
  MapPin,
  Users,
  Route,
  Luggage,
  ClipboardList,
  ArrowRight,
  Check,
} from 'lucide-react';

const services = [
  {
    icon: Car,
    title: 'Car + Driver',
    description: 'Book a comfortable car with a professional driver for your complete journey.',
    useCases: ['Local trips', 'Outstation trips', 'Family trips', 'Business travel', 'Airport transfers', 'Events'],
    button: 'Book Car + Driver',
  },
  {
    icon: MapPin,
    title: 'Pickup & Drop',
    description: 'Reliable transportation from your home, hotel, airport, railway station or destination.',
    button: 'Plan Pickup & Drop',
  },
  {
    icon: Users,
    title: 'Group & Corporate Travel',
    description: 'Comfortable transportation solutions for groups, colleges, companies, weddings and events.',
    vehicleOptions: ['Sedan', 'SUV', 'Tempo Traveller', 'Mini Bus'],
    button: 'Plan Group Travel',
  },
  {
    icon: Route,
    title: 'Multi-Stop Trips',
    description: 'Travel to multiple destinations with one vehicle and one complete trip plan.',
    exampleRoute: 'Guntur → Vijayawada → Hyderabad → Guntur',
    interactive: true,
    button: 'Plan Multi-Stop Trip',
  },
  {
    icon: Luggage,
    title: 'Luggage & Travel Support',
    description: 'Make your journey easier with additional travel and luggage transportation support.',
    features: ['Luggage transportation', 'Multiple pickup points', 'Hotel transfers', 'Travel coordination'],
    button: 'Get Travel Support',
  },
  {
    icon: ClipboardList,
    title: 'Trip Planning',
    description: 'Create a complete transportation plan based on your destination, passengers and travel requirements.',
    button: 'Create Trip Plan',
  },
];

export function LogisticsServices() {
  return (
    <section id="logistics-services" className="relative bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-gold-dark">
            Logistics Services
          </span>
          <h2 className="mt-3 font-playfair text-3xl font-bold text-charcoal sm:text-4xl md:text-5xl">
            Everything You Need for Your Journey
          </h2>
          <p className="mt-4 text-base text-charcoal/60 sm:text-lg">
            Six complete travel logistics services — from a single car with
            driver to full trip planning for groups and events.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-charcoal/8 bg-white p-7 transition-all duration-500 hover:border-gold/50 hover:shadow-charcoal"
              >
                {/* Hover gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-gold/0 to-gold/0 transition-all duration-500 group-hover:from-gold/5 group-hover:to-transparent" />

                {/* Icon */}
                <div className="relative mb-5">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-charcoal text-gold transition-all duration-500 group-hover:bg-gold-gradient group-hover:text-charcoal group-hover:scale-110">
                    <Icon className="h-7 w-7" />
                  </div>
                </div>

                {/* Title */}
                <h3 className="relative font-playfair text-xl font-bold text-charcoal">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="relative mt-2 text-sm leading-relaxed text-charcoal/60">
                  {service.description}
                </p>

                {/* Use cases */}
                {service.useCases && (
                  <div className="relative mt-4 flex flex-wrap gap-1.5">
                    {service.useCases.map((useCase) => (
                      <span
                        key={useCase}
                        className="rounded-full bg-charcoal/5 px-2.5 py-1 text-xs text-charcoal/60"
                      >
                        {useCase}
                      </span>
                    ))}
                  </div>
                )}

                {/* Vehicle options */}
                {service.vehicleOptions && (
                  <div className="relative mt-4 space-y-2">
                    {service.vehicleOptions.map((vehicle) => (
                      <div key={vehicle} className="flex items-center gap-2 text-sm text-charcoal/70">
                        <Check className="h-3.5 w-3.5 text-gold-dark" />
                        {vehicle}
                      </div>
                    ))}
                  </div>
                )}

                {/* Example route */}
                {service.exampleRoute && (
                  <div className="relative mt-4 rounded-lg border border-gold/20 bg-gold/5 px-4 py-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-gold-dark">
                      Example Route
                    </p>
                    <p className="mt-1 text-sm font-medium text-charcoal">
                      {service.exampleRoute}
                    </p>
                    <button className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-gold-dark transition-colors hover:text-charcoal">
                      + Add Stop
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                )}

                {/* Features */}
                {service.features && (
                  <div className="relative mt-4 space-y-2">
                    {service.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2 text-sm text-charcoal/70">
                        <Check className="h-3.5 w-3.5 text-gold-dark" />
                        {feature}
                      </div>
                    ))}
                  </div>
                )}

                {/* Button */}
                <div className="relative mt-6 pt-2">
                  <a
                    href="#trip-planner"
                    className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-charcoal/15 px-5 py-2.5 text-sm font-semibold text-charcoal transition-all duration-300 hover:border-gold hover:bg-gold-gradient hover:text-charcoal"
                  >
                    {service.button}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
